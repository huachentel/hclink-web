#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

#upgrade.image=upgrade.meta+upgrade.file
PREFIX="${DATA_ROOT}/tmp"
UPGRADE_IMG="${PREFIX}/upgrade.img"
META_FILE="${PREFIX}/upgrade.meta"
META_HEADER_LEN='512'
UPGRADE_FILE="${PREFIX}/upgrade.file"
DEVICE_INFO="${PREFIX}/device_info"
UPGRADE_STAGE2_PATH="${DATA_ROOT}/recovery"

#get key=value $1:key
p_get() {
  if [ ! -z "$1" ]; then
    echo "$(grep -a "^$1=" $META_FILE | sed "s,$1=,,")"
  fi
}

upgrade_stage1() {
  local image_md5
  local file_md5
  local support_device
  local device_info

  if [ ! -f $UPGRADE_IMG ]; then
    echo "ERR: Need '$UPGRADE_IMG'"
    return 1
  fi

  rm -rf $UPGRADE_FILE
  rm -rf $META_FILE

  device_info="$(uci_get system @devinfo[0] InternalModelName)"
  if [ -z "$device_info" ]; then
    echo "Can not get device info"
    return 1
  fi

  #get meta info
  dd if=$UPGRADE_IMG bs=$META_HEADER_LEN count=1 of=$META_FILE &>/dev/null
  support_device="$(p_get 'support_device')"
  image_md5="$(p_get 'md5')"
  rm -rf $META_FILE
  if [ -z "$support_device" -o -z "$image_md5" ]; then
    echo "Invalid image metadata"
    return 1
  fi

  #get upgrade image
  dd if=$UPGRADE_IMG bs=$META_HEADER_LEN skip=1 of=$UPGRADE_FILE &>/dev/null
  file_md5=$(md5sum $UPGRADE_FILE | awk '{print $1}')
  if [ "$image_md5" != "$file_md5" ]; then
    echo "Image MD5 Error!"
    rm -rf $UPGRADE_FILE
    return 1
  fi

  for device in $support_device; do
    if [ "$device_info" == "$device" ]; then
      #INSTALL
      rm -rf ${UPGRADE_STAGE2_PATH}/new/*
      mv $UPGRADE_FILE ${UPGRADE_STAGE2_PATH}/new
      echo "updating" >${UPGRADE_STAGE2_PATH}/status
      echo "reboot and start upgrade stage2"
      #
      sync
      reboot
      return 0
    fi
  done

  echo "Device $device_info not supported by this image!"
  echo "Supported devices:"
  for device in $support_device; do
    echo "$device"
  done

  return 1
}

fibo_upgrade_state1() {
  if [ ! -d "/cache/recovery" ]; then
    mkdir -p /cache/recovery
  fi
  rm -rf /cache/recovery/*
  touch /cache/recovery/command
  if [ -f "/cache/fibo_upgrade_delta.zip" ]; then
    rm -rf /cache/fibo_upgrade_delta.zip
  fi
  mv $UPGRADE_IMG /cache/fibo_upgrade_delta.zip

  echo --update_package=/cache/fibo_upgrade_delta.zip >/cache/recovery/command
  echo "fibo_updating" >${UPGRADE_STAGE2_PATH}/status
  sync
  sys_reboot recovery
}

#读取包头信息，看是那种升级包，执行对应的升级流程
TYPE_FLAG=$(head -c 25 $UPGRADE_IMG)
if [ "${TYPE_FLAG}" == "type=hclink_upgrade_image" ]; then
  upgrade_stage1
else
  fibo_upgrade_state1
fi
