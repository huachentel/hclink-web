#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

DOWNLOAD_DIR="${DATA_ROOT}/tmp"
IMG_NAME="upgrade.img"
COMMANDKEY_SAVE_FILE="${DATA_ROOT}/recovery/command_key"

download() {
  local url="$(uci_get download 1 URL)"
  local file_type="$(uci_get download 1 FileType)"
  local file_size="$(uci_get download 1 FileSize)"
  local user_name="$(uci_get download 1 Username)"
  local password="$(uci_get download 1 Password)"
  local start_time="$(uci_get download 1 StartTime)"
  local command_key="$(uci_get download 1 CommandKey)"

  echo "URL=$url"
  echo "FileType=$file_type"
  echo "FileSize=$file_size"
  echo "Username=$user_name"
  echo "Password=$password"
  echo "StartTime=$start_time"
  echo "CommandKey=$command_key"
  #保存CommandKey
  echo -n $command_key >$COMMANDKEY_SAVE_FILE
  #clean
  rm -rf ${DOWNLOAD_DIR}/${IMG_NAME} 2>/dev/null
  rm -rf /data/fibo_upgrade_delta.zip 2>/dev/null
  #todo : grep "/$"
  dl_size=$(df | grep "/data$" | awk '{print $4;}')
  [ -n "$dl_size" ] && dl_size_byte=$((${dl_size} * 1024))
  if [ -n "$dl_size" -a "$dl_size_byte" -lt "$file_size" ]; then
    echo 'fault_code=-39010'
    exit 1
  else
    local dw_url="$url"
    #[ "$user_name" != "" -o "$password" != "" ] && dw_url=`echo "$url" | sed -e "s@://@://$user_name:$password\@@g"`
    #wget -q -c -t 5 -T 5 -P $DOWNLOAD_DIR "$dw_url"  &> /dev/null

    # case "$url" in
    #     http://*|\
    #     https://*)
    #         ;;
    #     ftp://*)
    #         ;;
    # esac

    [ "$user_name" != "" -o "$password" != "" ] && dw_url=$(echo "$url")
    auth_base64=$(echo -n "${user_name}:${password}" | base64)
    wget -d -c -t 5 -T 15 -O ${DOWNLOAD_DIR}/${IMG_NAME} --no-check-certificate --header "Authorization:Basic $auth_base64" $dw_url &>${DATA_ROOT}/log/download.log

    fault_code="$?"
    if [ "$fault_code" != "0" ]; then
      rm -rf ${DOWNLOAD_DIR}/${IMG_NAME} 2>/dev/null
      echo 'fault_code=-39010'
      exit 1
    else
      echo 'fault_code=0'
    fi
  fi
}

download
