#!/usr/bin/env bash
#=====================================================================
# COPYSTR: Copyright (c) 2020 By HuachenLink, All Rights Reserved.
# FLENAME: wlan.sh
# CONTACT: liudongguo@huachen.link
# CREATED: 2020-11-14 06:54:49
# LTSVERN: 0.1
# LTSUPDT: 2020-11-17 00:04:02
#=====================================================================
#adopter-for-new-data-to-update-into-uci-settings
#[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
source ${AGENT_FS_ROOT:-/hclink}/system/lib/scripts/cpelib_core.sh &>/dev/null

CONFIG_FILE='wlan'

hcl.wlan() {
  local cfn=$CONFIG_FILE
  local cfp=${DATA_ROOT:-/data/hclink}/etc/config/$cfn
  [ -e $cfp ] || touch $cfp

  #==============================================
  _cok() { echo -e "[\e[32;1mOK\e[0m] $*"; }
  #==============================================
  _cwrn() { echo -e "[\e[31;43;5;1mWARN\e[0m] $*"; }
  ##STATUS===========================================================
  _get() {
    while :; do
      uci_remove $cfn "@${cfn}[-1]" &>/dev/null
      [ $? -ne 0 ] && uci commit $cfn && break
    done
    #--------------------------------------------
    local curSection="@${cfn}[-1]" obj=$cfn syi=
    awk '/^(ssid|interface|wpa_passphrase|hw_mode|channel|bridge|country_code)=/' $apcfgfile >/tmp/using.$obj
    source /tmp/using.$obj
    uci_add $cfn $obj
    uci_set $cfn "$curSection" "instance_num" "1"
    uci_set $cfn "$curSection" "BeaconType" "WPA2"
    uci_set $cfn "$curSection" "WPAAuthenticationMode" "WPA2/WPS-PSK"
    local apstd='wifi4' atype='2.4G'
    if [ "X$hw_mode" == "Xa" ]; then
      apstd='wifi5' && atype='5G'
    fi
    uci_set $cfn "$curSection" "Standard" $apstd
    uci_set $cfn "$curSection" "X_CU_Band" "${atype}"
    uci_set $cfn "$curSection" "BandWidth" "20MHz"
    uci_set $cfn "$curSection" "AutoChannelEnable" "0"
    uci_set $cfn "$curSection" "Channel" "${channel}"
    uci_set $cfn "$curSection" "PreSharedKey" "${wpa_passphrase}"
    uci_set $cfn "$curSection" "SSID" "${ssid}"
    uci_set $cfn "$curSection" "Interface" "${interface}"
    uci_set $cfn "$curSection" "CountryCode" "${country_code}"
    # uci_set $cfn "$curSection" "Bridge" "${bridge}"

    [ "X$(pgrep hostapd 2>/dev/null | xargs)" != "X" ] && flgEnable=1 || flgEnable=0
    uci_set $cfn "$curSection" "Enable" "${flgEnable}"
    uci commit
  }
  ##CONFIG===========================================================
  _set() {
    #---------------------------------
    __uptSvc() {
      echo $hdrtip
      echo && echo '[Unit]'
      echo "Description=HCLINK-WIFI-Daemon on wireless iface $wlsnic"
      echo "Requires=sys-subsystem-net-devices-$wlsnic.device"
      echo "After=sys-subsystem-net-devices-$wlsnic.device"
      echo 'Before=network.target'
      echo 'Wants=network.target'
      echo && echo '[Service]'
      echo 'ExecStart=/usr/sbin/hostapd '$apcfgfile
      echo 'ExecReload=/bin/kill -HUP $MAINPID'
      echo 'TimeoutStartSec=30s'
      echo 'Restart=on-failure'
      echo 'RestartSec=30s'
      echo && echo '[Install]'
      echo 'WantedBy=multi-user.target'
      echo $hdrtip && echo
    }
    #---------------------------------
    __uptCfg() {
      echo $hdrtip
      echo 'ssid='$SSID
      echo 'interface='${Interface:-$wlsnic}
      [ "X$BeaconType" == "XNone" ] && cmt='#' || cmt=
      echo ${cmt}'wpa_passphrase='$PreSharedKey
      echo ${cmt}'wpa=2'
      echo ${cmt}'rsn_pairwise=CCMP'
      echo ${cmt}'wpa_key_mgmt=WPA-PSK'
      [ "X$g_osflag" == "X" ] && echo 'bridge=br-lan'
      echo 'country_code='${CountryCode:-CN}
      echo 'ieee80211n=1'
      echo 'require_ht=1'
      case $X_CU_Band in
      5G | 5.[268]G)
        echo 'hw_mode=a'
        echo 'channel='${Channel:-157}
        echo 'ieee80211ac=1'
        echo 'ht_capab=[SHORT-GI-40][HT40+][RXLDPC][TX-STBC-2BY1][RX-STBC-1]'
        echo 'ieee80211d=1'
        echo 'ieee80211h=1'
        echo 'require_vht=1'
        echo 'vht_oper_chwidth=1'
        echo 'vht_oper_centr_freq_seg0_idx=155'
        echo 'vht_capab=[MAX-MPDU-11454][SHORT-GI-80][RXLDPC][TX-STBC-2BY1][RX-STBC-1]'
        ;;
      *)
        echo 'hw_mode=g'
        echo 'channel='${Channel:-11}
        echo 'ht_capab=[SHORT-GI-40][HT20][RX-STBC1][DSSS_CCK-40]'
        ;;
      esac
      echo
      echo '#beacon_int=100'
      echo '#obss_interval=0'
      echo 'dtim_period=2'
      echo 'max_num_sta=255'
      echo 'rts_threshold=2347'
      echo '#fragm_threshold=2346'
      echo 'macaddr_acl=0'
      echo 'auth_algs=3'
      echo 'ignore_broadcast_ssid=0'
      echo 'ap_isolate=0'
      echo 'wmm_enabled=1'
      echo 'eapol_key_index_workaround=0'
      echo 'eap_server=0'
      echo 'own_ip_addr=127.0.0.1'
      echo 'logger_syslog=-1'
      echo 'logger_syslog_level=2'
      echo 'logger_stdout=-1'
      echo 'logger_stdout_level=2'
      echo 'ctrl_interface=/var/run/hostapd'
      echo 'ctrl_interface_group=0'
      echo $hdrtip
      echo
    }
    #-----------------------------------
    local obj=$cfn
    local fctn=/tmp/$obj.content
    uci show $cfn.@$obj[0] 2>/dev/null >$fctn
    if [ -s $fctn ]; then
      awk -F'.' 'NR>1{$1=$2="";print}' $fctn | xargs -n1 | sed 's# #.#g' >/tmp/$obj.env
      source /tmp/$obj.env
      __uptCfg >$apcfgfile
      if [ "X$Enable" == "X1" ]; then
        __uptSvc >/lib/systemd/system/hostapd${wlsidx}.service
        systemctl unmask hostapd
        systemctl enable hostapd
        systemctl restart hostapd
      fi
    fi
  }
  #===MAIN====================================================
  if [ "X$(command -v uci 2>/dev/null)" == "X" ] ||
    [ "X$(command -v uci_set 2>/dev/null)" == "X" ]; then
    return 1
  fi
  local op=$1
  if [[ "X$op" != "Xstatus" && "X$op" != "Xconfig" ]]; then
    echo "Usage: $tNAME {status|config}"
    return 2
  fi
  shift
  local hdrtip="## re-generateby HCLINK @$(date +'%F %T')@"
  local tNAME=$(tn=${BASH_SOURCE##*/} && echo ${tn})
  local wlsidx=${CFG_WLS_INDEX} wlsnic=${CFG_WLS_INDEX}
  [ "X$wlsnic" == "X" ] && wlsnic=$(cd /sys/class/net && echo wl*)
  [ "X$wlsnic" == "X" ] && wlsnic='wlp1s0'
  local apcfgfile=/etc/hostapd/hostap${wlsidx}.cnf
  #-----------------------------------
  [ -e $cfn ] && cp $cfn /data/hclink/etc/config && uci commit
  [ ${G_BAK_CFG-0} -eq 1 ] && cp $cfp /opt/bak.${cfn}.$op
  #-----------------------------------
  case $op in
  status) _get $@ ;;
  config) _set $@ ;;
  esac
}

[ "X${0: -4}" = "Xbash" ] || hcl.wlan $@
