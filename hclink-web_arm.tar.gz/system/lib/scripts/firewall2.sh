#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

ACL_CONFIG_FILE="firewall2_acl"
ACL_TMP_FILE="$DATA_ROOT/tmp/acl.tmp"

#以下端口不可禁掉
privileged_ports="80 8848 22"

acl_status() {
  local i
  #pkts bytes target prot opt in out source destination
  iptables -L FORWARD -nv | awk '$3=="DROP" || $3=="ACCEPT"  {print  $0}' >$ACL_TMP_FILE
  i=1

  #clean
  while :; do
    uci_remove $ACL_CONFIG_FILE "@rule[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
  #get
  while read line; do
    [ -z "$line" ] && continue
    SrcIP="$(echo "$line" | awk '{print $8}')"
    DstIP="$(echo "$line" | awk '{print $9}')"
    SrcPort="$(echo "$line" | awk '$10=="tcp" || $10=="udp" {print $11}' | awk -F: '$1=="spt"  {print $2}')"
    DstPort="$(echo "$line" | awk '$10=="tcp" || $10=="udp" {print $11}' | awk -F: '$1=="dpt"  {print $2}')"
    Protocol="$(echo "$line" | awk '{print $4}')"
    SrcMac="$(echo "$line" | awk '$10=="MAC" {print $11}')"
    In="$(echo "$line" | awk '{print $6}')"

    uci_add $ACL_CONFIG_FILE "rule" $i
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'instance_num' $i
    if [ "$SrcIP" != "0.0.0.0/0" ]; then
      uci_set $ACL_CONFIG_FILE "@rule[-1]" 'SrcIP' "$SrcIP"
    fi
    if [ "$DstIP" != "0.0.0.0/0" ]; then
      uci_set $ACL_CONFIG_FILE "@rule[-1]" 'DstIP' "$DstIP"
    fi
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'SrcPort' "$SrcPort"
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'DstPort' "$DstPort"
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'Protocol' "$Protocol"
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'SrcMac' "$SrcMac"
    if [ "$In" != "*" ]; then
      uci_set $ACL_CONFIG_FILE "@rule[-1]" 'In' "$In"
    fi
    let 'i+=1'
  done <$ACL_TMP_FILE
}

#$1 instance num
acl_add() {
  local SrcIP
  local DstIP
  local SrcPort
  local DstPort
  local Protocol
  local SrcMac
  local In
  local Mode

  local is_tcp_udp
  local ignore
  
  if [ -z "$1" ]; then
    ret 1
    return 1
  fi

  SrcIP="$(uci_get $ACL_CONFIG_FILE $1 SrcIP)"
  DstIP="$(uci_get $ACL_CONFIG_FILE $1 DstIP)"
  SrcPort="$(uci_get $ACL_CONFIG_FILE $1 SrcPort)"
  DstPort="$(uci_get $ACL_CONFIG_FILE $1 DstPort)"
  Protocol="$(uci_get $ACL_CONFIG_FILE $1 Protocol)"
  SrcMac="$(uci_get $ACL_CONFIG_FILE $1 SrcMac)"
  In="$(uci_get $ACL_CONFIG_FILE $1 In)"
  #1:白名单　2:黑名单
  Mode="$(uci_get $ACL_CONFIG_FILE @config[0] Mode)"

  if [ -z "$SrcIP" ] && [ -z "$DstIP" ] && [ -z "$SrcPort" ] && [ -z "$DstPort" ] && [ -z "$In" ] && [ -z "$SrcMac" ]; then
    #不允许丢弃全部,不允许只禁止tcp
    if [ -z "$Protocol" ] || [ "$Protocol" == "all" ] || [ "$Protocol" == "tcp" ]; then
      ret 1
      return 1
    fi
  fi

  if [ "$Protocol" == 'tcp' ] || [ "$Protocol" == 'udp' ]; then
    is_tcp_udp=1
  fi

  if [ "$Protocol" == 'all' ]; then
    Protocol=""
  fi

  if [ "$SrcIP" == "0.0.0.0/0" ]; then
    SrcIP=""
  fi

  if [ "$DstIP" == "0.0.0.0/0" ]; then
    DstIP=""
  fi

  #黑名单
  if [ $Mode == "2" ]; then
    ignore=0
    #特定端口黑名单配置忽略
    for i in $privileged_ports; do
      if [ "$i" == "$DstPort" ]; then
        ignore=1
      fi
    done

    if [ "$ignore" != "1" ]; then
      hc_exec "iptables -A INPUT ${Protocol:+ -p $Protocol} \
        ${SrcIP:+ -s $SrcIP} \
        ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
        ${DstIP:+ -d $DstIP} \
        ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
        ${SrcMac:+ -m mac --mac-source $SrcMac}\
        ${In:+ -i $In}\
        -j DROP"
      ret $?
    fi
    #转发禁止
    iptables -A FORWARD ${Protocol:+ -p $Protocol} \
      ${SrcIP:+ -s $SrcIP} \
      ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
      ${DstIP:+ -d $DstIP} \
      ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
      ${SrcMac:+ -m mac --mac-source $SrcMac}\
      ${In:+ -i $In}\
      -j DROP
    ret $?
  else
  #白名单
    iptables -A INPUT ${Protocol:+ -p $Protocol} \
      ${SrcIP:+ -s $SrcIP} \
      ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
      ${DstIP:+ -d $DstIP} \
      ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
      ${SrcMac:+ -m mac --mac-source $SrcMac}\
      ${In:+ -i $In}\
      -j ACCEPT
    ret $?

    iptables -A FORWARD ${Protocol:+ -p $Protocol} \
      ${SrcIP:+ -s $SrcIP} \
      ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
      ${DstIP:+ -d $DstIP} \
      ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
      ${SrcMac:+ -m mac --mac-source $SrcMac}\
      ${In:+ -i $In}\
      -j ACCEPT
    ret $?
  fi
}

#删除指定的rule
acl_del() {
  local SrcIP
  local DstIP
  local SrcPort
  local DstPort
  local Protocol
  local SrcMac
  local In

  local is_tcp_udp

  if [ -z "$1" ]; then
    ret 1
    return 1
  fi

  #连续删除会导致序号发生变化，故不使用下面的方法
  #iptables -D INPUT $1

  SrcIP="$(uci_get $ACL_CONFIG_FILE $1 SrcIP)"
  DstIP="$(uci_get $ACL_CONFIG_FILE $1 DstIP)"
  SrcPort="$(uci_get $ACL_CONFIG_FILE $1 SrcPort)"
  DstPort="$(uci_get $ACL_CONFIG_FILE $1 DstPort)"
  Protocol="$(uci_get $ACL_CONFIG_FILE $1 Protocol)"
  SrcMac="$(uci_get $ACL_CONFIG_FILE $1 SrcMac)"
  In="$(uci_get $ACL_CONFIG_FILE $1 In)"

  if [ "$Protocol" == 'tcp' ] || [ "$Protocol" == 'udp' ]; then
    is_tcp_udp=1
  fi

  if [ "$Protocol" == 'all' ]; then
    Protocol=""
  fi

  if [ "$SrcIP" == "0.0.0.0/0" ]; then
    SrcIP=""
  fi

  if [ "$DstIP" == "0.0.0.0/0" ]; then
    DstIP=""
  fi

  iptables -D INPUT ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    ${SrcMac:+ -m mac --mac-source $SrcMac}\
    ${In:+ -i $In}\
    -j DROP &> /dev/null
  
  iptables -D INPUT ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    ${SrcMac:+ -m mac --mac-source $SrcMac}\
    ${In:+ -i $In}\
    -j ACCEPT &> /dev/null

  #同时删除forward链
  iptables -D FORWARD ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    ${SrcMac:+ -m mac --mac-source $SrcMac}\
    ${In:+ -i $In}\
    -j DROP &> /dev/null
  
  iptables -D FORWARD ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    ${SrcMac:+ -m mac --mac-source $SrcMac}\
    ${In:+ -i $In}\
    -j ACCEPT &> /dev/null

  uci_remove $ACL_CONFIG_FILE $1
}

#清除所有规则
acl_flush() {
  local Mode
  Mode=$(uci_get $ACL_CONFIG_FILE "@config[0]" Mode)

  iptables -F INPUT
  iptables -F FORWARD
  #白名单清空且添加预留端口许可
  if [ "$Mode" == "1" ]; then
    for i in $privileged_ports; do
      iptables -A INPUT -p tcp --dport $i -j ACCEPT
    done
  fi

  while :; do
    uci_remove $ACL_CONFIG_FILE "@rule[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
}

#$1: mode , 1, white 2. black
mode_change()
{
  iptables -F INPUT
  iptables -F FORWARD
  while :; do
    uci_remove $ACL_CONFIG_FILE "@rule[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
  #白名单清空且添加预留端口许可
  if [ "$1" == "1" ]; then
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    for i in $privileged_ports; do
      iptables -A INPUT -p tcp --dport $i -j ACCEPT
    done
  else
    iptables -P INPUT ACCEPT
    iptables -P FORWARD ACCEPT
  fi
}

acl_config_get() {
  local policy

  uci_get $ACL_CONFIG_FILE "@config[0]" &>/dev/null
  if [ "$?" != "0" ]; then
    uci_add $ACL_CONFIG_FILE "config"
  fi
  uci_set $ACL_CONFIG_FILE "@config[0]" 'instance_num' "1"

  systemctl status ssh &> /dev/null
  if [ "$?" == "0" ]; then
    uci_set $ACL_CONFIG_FILE "@config[0]" 'SSHEnable' "1"
  else
    uci_set $ACL_CONFIG_FILE "@config[0]" 'SSHEnable' "0"
  fi

  policy="$(iptables -S INPUT | awk '/-P INPUT/ {print $3}')"
  if [ "$policy" == "ACCEPT" ]; then
    uci_set $ACL_CONFIG_FILE "@config[0]" 'Mode' "2"
  else
    uci_set $ACL_CONFIG_FILE "@config[0]" 'Mode' "1"
  fi

  #不支持telnet
  uci_set $ACL_CONFIG_FILE "@config[0]" 'TelnetEnable' "0"
}

#$1 对应config下的参数
acl_config_set() {
  local value

  value=$(uci_get $ACL_CONFIG_FILE "@config[0]" $1)
  case $1 in
  'SSHEnable')
    if [ "$value" == "1" ]; then
      echo 'ssh enable'
      systemctl start ssh
    else
      echo 'ssh disable'
      systemctl stop ssh
    fi
    ;;
  'TelnetEnable')
    if [ "$value" == "1" ]; then
      echo 'telnet enable'
    else
      echo 'telnet disable'
    fi
    ;;
  'Mode')
    mode_change "$value"
    ;;
  'RuleClean')
    acl_flush
    ;;
  *)
    echo {'SSHEnable|TelnetEnable|Mode|RuleClean'}
    ;;
  esac
}

if [ ! -f ${DATA_ROOT}/etc/config/$ACL_CONFIG_FILE ]; then
  touch ${DATA_ROOT}/etc/config/$ACL_CONFIG_FILE
fi

case $1 in
'acl')
  case $2 in
  'status')
    acl_status
    uci_commit $ACL_CONFIG_FILE
    ;;
  'add')
    acl_add $3
    ;;
  'del')
    acl_del $3
    ;;
  'config')
    case $3 in
    'get')
      acl_config_get $4
      ;;
    'set')
      acl_config_set $4
      ;;
    *)
      echo '{get|set}'
      ;;
    esac
    ;;
  *)
    echo '{status|add|del|config}'
    ;;
  esac
  ;;
*)
  echo '{acl}'
  ;;
esac

_exit
