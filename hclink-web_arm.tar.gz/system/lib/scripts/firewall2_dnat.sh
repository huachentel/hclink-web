#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

DNAT_CONFIG_FILE="firewall2_dnat"
# DNAT_CONFIG_FILE="/data/hclink/etc/config/firewall2_dnat"
DNAT_TMP_FILE="$DATA_ROOT/tmp/dnat.tmp"
IPTABLE_SAVE_FILE="$DATA_ROOT/etc/iptable-save"


dnat_status()
{
    iptables -t nat -nvL | awk '$3=="DNAT"'  |grep -v all |sed 's/:/ /g' > $DNAT_TMP_FILE
    local i=1

    #clean
    while true
    do 
        uci_remove $DNAT_CONFIG_FILE "@dnat[0]" &>/dev/null
        if [ $? == 1 ]; then
            break
        fi
    done

    while true
    do 
        uci_remove $DNAT_CONFIG_FILE "@dmz[0]" &>/dev/null
        if [ $? == 1 ]; then
            break
        fi
    done

    # echo "" >$DNAT_CONFIG_FILE
    #read
    while read line; do
        [ -z "$line" ] && continue
        OutDev="$(echo "$line" | awk '{print $6}')"  
        Protocol="$(echo "$line" | awk '{print $4}')"
        SrcPort="$(echo "$line" | awk '{print $12}')"
        DstIP="$(echo "$line" | awk '{print $14}')"
        DstPort="$(echo "$line" | awk '{print $15}')"

        uci_add $DNAT_CONFIG_FILE "dnat" $i
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]" 'instance_num' $i
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]" 'OutDev' $OutDev
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]" 'SrcPort' $SrcPort
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]" 'DstIP' $DstIP
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]" 'DstPort' $DstPort
        uci_set $DNAT_CONFIG_FILE "@dnat[-1]"  'Protocol'  $Protocol

        let i++
    done <$DNAT_TMP_FILE
}

dnat_add(){
    local dev
    local srcport
    local dstip
    local dstport
    local protoco

    if [ -z "$1" ]; then
        return 1
    fi

    dev=$(uci_get $DNAT_CONFIG_FILE $1 OutDev)
    srcport=$(uci_get $DNAT_CONFIG_FILE $1 SrcPort)
    dstip=$(uci_get $DNAT_CONFIG_FILE $1 DstIP)
    dstport=$(uci_get $DNAT_CONFIG_FILE $1 DstPort)
    protocol=$(uci_get $DNAT_CONFIG_FILE $1 Protocol)

    # echo $dev $srcport $dstip $dstport  $protocol

    if [ "$protocol" = "all" ]; then
        iptables -t nat -A PREROUTING -i $dev -p tcp --dport $srcport -j DNAT --to $dstip:$dstport
        iptables -t nat -A PREROUTING -i $dev -p udp --dport $srcport -j DNAT --to $dstip:$dstport
    else
        iptables -t nat -A PREROUTING -i $dev -p $protocol --dport $srcport -j DNAT --to $dstip:$dstport

    fi
    iptables-save > $IPTABLE_SAVE_FILE
    return 0
}


dnat_del(){
    local dev
    local srcport
    local dstip
    local dstport
    
    if [ -z "$1" ]; then
        return 1
    fi

    dev=$(uci_get $DNAT_CONFIG_FILE $1 OutDev)
    srcport=$(uci_get $DNAT_CONFIG_FILE $1 SrcPort)
    dstip=$(uci_get $DNAT_CONFIG_FILE $1 DstIP)
    dstport=$(uci_get $DNAT_CONFIG_FILE $1 DstPort)
    protocol=$(uci_get $DNAT_CONFIG_FILE $1 Protocol)

    # echo $dev $srcport $dstip $dstport  $protocol

    if [ "$protocol" = "all" ]; then
        iptables -t nat -D PREROUTING -i $dev -p tcp --dport $srcport -j DNAT --to $dstip:$dstport
        iptables -t nat -D PREROUTING -i $dev -p udp --dport $srcport -j DNAT --to $dstip:$dstport
    else
        iptables -t nat -D PREROUTING -i $dev -p $protocol --dport $srcport -j DNAT --to $dstip:$dstport 

    fi
    iptables-save > $IPTABLE_SAVE_FILE
    return 0
}

dnat_flush(){
    local num
    local j=1
    num=$(uci show  firewall2_dnat | awk /instance_num/ |wc -l)
    let num--

    dnat_status
    while [ $num -ge $j ];
    do
        dnat_del $j
        let j++
    done
}

dnat_config_set(){
    local value

    value=$(uci_get $DNAT_CONFIG_FILE "@config[0]" RuleClean)
    if [ "$value" == "1" ]; then
        dnat_flush
    fi
}

dmz_status(){
    iptables -t nat -nvL | awk '$3=="DNAT"'  |grep  all |sed 's/:/ /g' > $DNAT_TMP_FILE
    local i=1
    #clean
    while true
    do 
        uci_remove $DNAT_CONFIG_FILE "@dmz[0]" &>/dev/null
        if [ $? == 1 ]; then
            break
        fi
    done

    while true
    do 
        uci_remove $DNAT_CONFIG_FILE "@dnat[0]" &>/dev/null
        if [ $? == 1 ]; then
            break
        fi
    done

    #read
    while read line; do
        [ -z "$line" ] && continue
        DMZDEV="$(echo "$line" | awk '{print $6}')"  
        DMZIP="$(echo "$line" | awk '{print $11}')"  

        uci_add $DNAT_CONFIG_FILE "dmz" $i
        uci_set $DNAT_CONFIG_FILE "@dmz[-1]" 'instance_num' $i
        uci_set $DNAT_CONFIG_FILE "@dmz[-1]" 'DMZDEV' $DMZDEV
        uci_set $DNAT_CONFIG_FILE "@dmz[-1]" 'DMZIP' $DMZIP
        let i++
    done <$DNAT_TMP_FILE
}


dmz_add(){
    local DMZDEV
    local DMZIP

    if [ -z "$1" ]; then
        return 1
    fi

    DMZDEV=$(uci_get $DNAT_CONFIG_FILE $1 DMZDEV)
    DMZIP=$(uci_get $DNAT_CONFIG_FILE $1 DMZIP)

    # echo $DMZDEV 
    # echo $DMZIP
    
    # echo "iptables -t nat -D PREROUTING -i $DMZDEV -j DNAT --to $DMZIP">/leslie/log
    echo $1 >>/leslie/log
    iptables -t nat -A PREROUTING -i $DMZDEV -j DNAT --to $DMZIP
    iptables-save > $IPTABLE_SAVE_FILE
    return 0
}

dmz_del(){
    local DMZDEV
    local DMZIP

    if [ -z "$1" ]; then
        return 1
    fi

    DMZDEV=$(uci_get $DNAT_CONFIG_FILE $1 DMZDEV)
    DMZIP=$(uci_get $DNAT_CONFIG_FILE $1 DMZIP)

    
    # echo "iptables -t nat -D PREROUTING -i $DMZDEV -j DNAT --to $DMZIP">/leslie/log
    iptables -t nat -D PREROUTING -i $DMZDEV -j DNAT --to $DMZIP
    iptables-save > $IPTABLE_SAVE_FILE
    return 0
}


dmz_flush(){
    local num
    local j=1
    dmz_status
    num=$(uci show  firewall2_dnat | awk /instance_num/ |wc -l)
    let num--
    
    while [ $num -ge $j ];
    do
        dmz_del $j
        let j++
    done
}

dmz_config_set(){
    local value
    value=$(uci_get $DNAT_CONFIG_FILE "@config[0]" RuleClean)
    # echo $value >/leslie/log
    if [ "$value" == "1" ]; then
        dmz_flush
    fi
}


case $1 in 
'dnat')
    case $2 in 
        'status')
            dnat_status
            uci_commit $ACL_CONFIG_FILE
            ;;
        'add')
            dnat_add $3
            ;;
        'del')
            dnat_del $3
            ;;
        'config')
            case $3 in
                'get')
                    dnat_config_get $4
                ;;
                'set')
                    dnat_config_set $4
                ;;
            esac
            ;;
    esac
    ;;
'dmz')
    case $2 in 
        'status')
            dmz_status
            uci_commit $ACL_CONFIG_FILE
            ;;
        'add')
            dmz_add  $3
            ;;
        'del')
            dmz_del  $3
            ;;
        'config')
            case $3 in
                'get')
                    dmz_config_get $4
                ;;
                'set')
                    dmz_config_set $4
                ;;
            esac
            ;;
    esac
    ;;
*)
    echo '{dnat|dmz   status|all|del}'
    ;;
esac



_exit