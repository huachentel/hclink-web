#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

NR5G_STATUS_FILE="nr5g_status"
AT_CLIENT="/usr/local/bin/atcmdtool"
if [ "$AGENT_SYSTEM" == "ubuntu" ]; then
  AT_CLIENT="/usr/local/bin/atcmdtool"
else
  AT_CLIENT="${AGENT_FS_ROOT}/system/bin/hclink_at_client"
fi

CONN_1_ALWAYS_ENABLE='1' #第一路连接始终保持开启
cell_info_get() {
  local info

  #UMTS
  $AT_CLIENT 'at+gtccinfo?' 2>/dev/null  >/var/log/gtccinfo
  info=$(cat /var/log/gtccinfo 2>/dev/null | awk '$0~/UMTS service cell/{getline; print $1;}')
  if [ -n "$info" ]; then
    cell_id=$(echo $info | awk -F, '{print $6}')
    rscp=$(echo $info | awk -F, '{print $11}')
    #change to dBm
    let "rscp=rscp-120"
    band=$(echo $info | awk -F, '{print $9}')
    return 0
  fi

  #LTE/eMTC/NB-IoT
  info=$(cat /var/log/gtccinfo 2>/dev/null | awk '$0~/(LTE|eMTC|NB-IoT) service cell/{getline; print $1;}')
  if [ -z "$info" ]; then
    #NR service cell
    info=$(cat /var/log/gtccinfo 2>/dev/null | awk '$0~/NR service cell/{getline; print $1;}')
    if [ -z "$info" ]; then
      #LTE-NR EN-DC service cell
      info=$(cat /var/log/gtccinfo 2>/dev/null | awk '$0~/LTE-NR EN-DC service cell/{getline; getline; print $1;}')
    fi
  fi

  if [ -n "$info" ]; then
    rat=$(echo $info | awk -F, '{print $2}')
    cell_id=$(echo $info | awk -F, '{print $6}')
    rsrp=$(echo $info | awk -F, '{print $13}')
    #change to dBm
    if [ "$rat" == "9" ]; then
      let "rsrp=rsrp-156"
    else
      let "rsrp=rsrp-140"
    fi

    rsrq=$(echo $info | awk -F, '{print $14}')
    band=$(echo $info | awk -F, '{print $9}')
    bandwidth=$(echo $info | awk -F, '{print $10}')
    if [ "$rat" == "9" ]; then
      sinr=$(echo $info | awk -F, '{print $11}')
    fi
  fi
}

csq_info_get() {
  local info
  info=$($AT_CLIENT 'at+csq?' 2>/dev/null | awk '/CSQ/ {print $2}')
  if [ -n "$info" ]; then
    rssi=$(echo $info | awk -F, '{print $1}')
    #change to dBm
    let "rssi=rssi*2-113"
    ber=$(echo $info | awk -F, '{print $2}')
  fi
}

#接入类型
# 0 GSM
# 1 GSM Compact
# 2 UTRAN
# 3 GSM w/EGPRS
# 4 UTRAN w/HSDPA
# 5 UTRAN w/HSUPA
# 6 UTRAN w/HSDPA and HSUPA
# 7 E-UTRAN
# 8 EC-GSM-IoT (A/Gb mode)
# 9 E-UTRAN (NB-S1 mode)
# 10 E-UTRA connected to a 5GCN
# 11 NR connected to a 5GCN
# 12 NG-RAN
# 13 E-UTRA-NR dual connectivity
operator_info_get() {
  local info
  info=$($AT_CLIENT 'at+cops?' 2>/dev/null | awk '/COPS/ {$1=""; print $0}')
  if [ -n "$info" ]; then
    oper="$(echo $info | awk -F, '{print $3}' | sed 's/\"//g')"
    act=$(echo $info | awk -F, '{print $4}')
  fi
}

model_info_get() {
  local info
  info=$($AT_CLIENT 'at+cgmm' | head -2 | awk '{getline; print $1}')
  model="$info"
}

cell_lock_info_get() {
  local info
  info=$($AT_CLIENT 'at+gtcainfo?' 2>/dev/null | awk '/PCC/ {print $2}')
  earfcn=$(echo $info | awk -F, '{print $3}')
  pci=$(echo $info | awk -F, '{print $2}')
}

sim_info_get() {
  local info
  imsi=$($AT_CLIENT 'at+cimi?' 2>/dev/null | awk '/CIMI/ {print $2}')
  ccid=$($AT_CLIENT 'at+ccid?' 2>/dev/null | awk '/CCID/ {print $2}')
  info=$($AT_CLIENT 'at+cnum?' 2>/dev/null | awk '/CNUM/ {print $2}')
  msisdn=$(echo $info | awk -F, '{print $2}')
  #todo 带空格的字符串
  pin_state=$($AT_CLIENT 'at+cpin?' 2>/dev/null | awk '/CPIN/ {print $2 $3}')
}

statis_info_get() {
  local info
  info=$($AT_CLIENT 'at+gtstatis?' 2>/dev/null | awk '/GTSTATIS/ {print $2}')
  rx_rate=$(echo $info | awk -F, '{print $1}')
  tx_rate=$(echo $info | awk -F, '{print $2}')
}

print_info() {
  echo cell_id=$cell_id
  echo rscp=$rscp
  echo band=$band
  echo rat=$rat
  echo rsrp=$rsrp
  echo rsrq=$rsrq
  echo bandwidth=$bandwidth
  echo sinr=$sinr
  echo rssi=$rssi
  echo ber=$ber
  echo oper=$oper
  echo act=$act
  echo model=$model
  echo earfcn=$earfcn
  echo pci=$pci
  echo imsi=$imsi
  echo ccid=$ccid
  echo msisdn=$msisdn
  echo pin_state=$pin_state
}

fun_test() {
  cell_info_get
  csq_info_get
  operator_info_get
  model_info_get
  cell_lock_info_get
  sim_info_get
  print_info
}

nr5g_wireless_info_save() {
  cell_info_get
  csq_info_get
  operator_info_get
  model_info_get
  cell_lock_info_get
  statis_info_get

  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'cell_id' $cell_id
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rscp' $rscp
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'band' $band
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rat' $rat
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rsrp' $rsrp
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rsrq' $rsrq
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'bandwidth' $bandwidth
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'sinr' $sinr
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rssi' $rssi
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'ber' $ber
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'oper' "$oper"
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'act' $act
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'model' $model
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'earfcn' $earfcn
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'pci' $pci
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'rx_rate' $rx_rate
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'tx_rate' $tx_rate
}

nr5g_sim_info_save() {
  sim_info_get
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'imsi' $imsi
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'ccid' $ccid
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'msisdn' $msisdn
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'pin_state' $pin_state
}

# ./ate at+gtgps?
# +GTGPS:
# $GPGGA,064356.00,3639.763912,N,11708.093645,E,1,06,1.4,297.7,M,-4.0,M,,*7A
# $BDGGA,,,,,,0,,,,,,,,*77
# $GAGGA,,,,,,0,,,,,,,,*77
# $GPRMC,064356.00,A,3639.763912,N,11708.093645,E,0.5,199.2,040820,5.4,W,A,V*53
# $BDRMC,,V,,,,,,,,,,N,V*38
# $GARMC,,V,,,,,,,,,,N,V*38
# $GPGSA,A,2,02,05,12,13,25,29,,,,,,,1.7,1.4,0.9,1*2E
# $BDGSA,A,1,,,,,,,,,,,,,,,,*23
# $GAGSA,A,1,,,,,,,,,,,,,,,,*23
# $PQGSA,A,1,,,,,,,,,,,,,,,,*24
# $GPGSV,3,1,11,02,71,045,31,05,68,293,31,09,17,042,21,12,14,239,27,1*61
# $GPGSV,3,2,11,13,27,177,28,19,15,153,17,25,13,270,32,29,26,316,41,1*6B
# $GPGSV,3,3,11,07,06,081,,15,07,203,,30,04,112,,1*5B
# $GLGSV,1,1,04,65,66,022,26,88,75,028,25,81,28,327,40,66,42,219,,1*79

nr5g_location_info_save() {
  local info
  local lo
  local la
  info=$($AT_CLIENT 'at+gtgps?' 2>/dev/null | awk '/GPGGA/ {print $0}')
  lo=$(echo $info | awk -F, '{print $5}')
  la=$(echo $info | awk -F, '{print $3}')

  uci_set $NR5G_STATUS_FILE '@location[0]' 'lo' $lo
  uci_set $NR5G_STATUS_FILE '@location[0]' 'la' $la
}

nr5g_conn_info_save() {

  local nr_enable
  local nr_status
  local nr_if
  local nr_mode
  local nr_apn
  local nr_auto
  local nr_ppp_auth
  local nr_ppp_user
  local nr_ppp_passwd
  local nr_if_status

  # nr_status=$($AT_CLIENT  'AT+COPS?' | grep +COPS: | awk -F ',' '{print $4}')

  # if [ -z $nr_status ]; then
  #   nr_enable='0'
  # else
  #   nr_enable='1'
  #   #nr_mode=$nr_status
  # fi
  nr_status=$(cat /sys/class/net/usb0/operstate)
  if [ "$nr_status" == "down" ]; then
    nr_enable=0
  else
    nr_enable=1
  fi

  nr_auto=$($AT_CLIENT 'AT+GTAUTOCONNECT?' | grep GTAUTOCONNECT | awk '{print $2}')
  nr_if=$(ip to | grep usb.* | awk '{print $4}')
  nr_apn=$($AT_CLIENT 'AT+CGDCONT?' | awk -F ',' '$1 == "+CGDCONT: 1" {print $3}' | sed 's/\"//g')
  # uci_add $NR5G_STATUS_FILE '5GNR1_conn'
  # uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'instance_num' '1'
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'Interface' $nr_if
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'Enable' $nr_enable
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'Mode' 'ECM'
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'APN' $nr_apn
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'AutoConnection' $nr_auto
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'PPP_Auth' ''
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'PPP_User' ''
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'PPP_Password' ''
}

nr5g_conn_set() {
  local nr_auto
  local nr_diag

  nr_auto=$(uci_get $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'AutoConnection')
  nr_diag=$(uci_get $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'Enable')
  nr_apn=$(uci_get $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'APN')

  if [ "$nr_apn" ]; then
    $AT_CLIENT AT+CGDCONT=1,\"IPV4V6\",\"$nr_apn\"
    #$AT_CLIENT AT+CFUN=0
    #$AT_CLIENT AT+CFUN=1
  fi

  if [ "$nr_auto" == "1" ]; then
    $AT_CLIENT 'AT+GTAUTOCONNECT=1'
  else
    $AT_CLIENT 'AT+GTAUTOCONNECT=0'
  fi

  if [ "$nr_diag" == "1" ]; then
    $AT_CLIENT "AT+GTRNDIS=1,1"
  else
    $AT_CLIENT "AT+GTRNDIS=0,1"
  fi
  ret 1
  return 0
}

nr5g_lock_status_save() {
  local freq
  local sa
  sa=$($AT_CLIENT at+gtact? | awk '/GTACT/ {print $2}' | awk -F ',' '{print $1}')
  if [ "$sa" == "14" ]; then
    uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'SAOnly' '1'
    freq=$($AT_CLIENT at+gtact? | awk '/GTACT/ {print $2}' | sed 's/14,,,//g')
    if [ -z $freq ]; then
      uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'FreqLock' ''
    else
      uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'FreqLock' $freq
    fi
  else
    var=$($AT_CLIENT at+gtact? | awk -F ' ' '/GTACT/ {print $2}')
    uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'SAOnly' '0'
    uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'FreqLock' ${var:7}
  fi

}

nr5g_lock_set() {
  local freq
  local sa

  if [ -z "$1" ]; then
    ret 1
    return 1
  fi

  sa=$(uci_get $NR5G_STATUS_FILE '@5GNR1[0]' SAOnly)
  freq=$(uci_get $NR5G_STATUS_FILE '@5GNR1[0]' FreqLock)

  if [ -z "$sa" ]; then
    return 0
  fi

  if [ "$sa" == "0" ]; then
    $AT_CLIENT 'AT+GTACT=10'
  else
    $AT_CLIENT 'AT+GTACT='14,,,${freq}''
  fi
  return 0
}

status_log_clean() {
  echo "" >$UCI_CONFIG_DIR/nr5g_status
  rm -rf $UCI_CONFIG_TMP_DIR/nr5g_status
  uci_add $NR5G_STATUS_FILE 'netinfo'
  uci_set $NR5G_STATUS_FILE '@netinfo[0]' 'instance_num' '1'

  uci_add $NR5G_STATUS_FILE 'location'
  uci_set $NR5G_STATUS_FILE '@location[0]' 'instance_num' '1'

  uci_add $NR5G_STATUS_FILE '5GNR1_conn'
  uci_set $NR5G_STATUS_FILE '@5GNR1_conn[0]' 'instance_num' '1'

  uci_add $NR5G_STATUS_FILE '5GNR1'
  uci_set $NR5G_STATUS_FILE '@5GNR1[0]' 'instance_num' '1'
}

#$1 connection num
#$2 apn
apn_set() {

  $AT_CLIENT at+cgdcont=${1},\"IPV4V6\",\"${2}\"
  $AT_CLIENT at+gtrndis=0,${1}
  $AT_CLIENT at+gtrndis=1,${1}
}

#$1 connection num
#$2 enable?
conn_enable() {
  #第一路始终开启
  if [ "$CONN_1_ALWAYS_ENABLE" == "1" ] && [ "$1" == "1" ]; then
    return
  fi
  $AT_CLIENT at+gtrndis=${2},${1}
}

case $1 in
"netinfo")
  status_log_clean
  nr5g_wireless_info_save
  uci_commit $NR5G_STATUS_FILE
  ;;
"sim")
  status_log_clean
  nr5g_sim_info_save
  uci_commit $NR5G_STATUS_FILE
  ;;
"apn")
  apn_set $2 $3
  ;;
"conn_enable")
  conn_enable $2 $3
  ;;
"conn_status")
  status_log_clean
  nr5g_conn_info_save
  uci_commit $NR5G_STATUS_FILE
  ;;
"conn_set")
  nr5g_conn_set $2
  ;;
"location")
  status_log_clean
  nr5g_location_info_save
  uci_commit $NR5G_STATUS_FILE
  ;;
"lock_status")
  status_log_clean
  nr5g_lock_status_save
  uci_commit $NR5G_STATUS_FILE
  ;;
"lock_set")
  nr5g_lock_set $2
  ;;
*)
  echo "{netinfo|sim}"
  ;;
esac
