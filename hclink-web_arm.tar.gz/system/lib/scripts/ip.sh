#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

AT_CLIENT="${AGENT_FS_ROOT}/system/bin/hclink_at_client"

function mask_to_prefix() {
  mask=${1}
  prefix_cnt=0
  prefix=""
  local mask_list=($(echo ${mask} | awk -F. '{print $1,$2,$3,$4}'))
  local mask_cnt=${#mask_list[*]}
  mask_cnt=$((${mask_cnt} - 1))
  for i in $(seq 0 ${mask_cnt}); do
    tmp=$(echo "obase=2;ibase=10;${mask_list[$i]}" | bc)
    prefix="${prefix}${tmp}"
  done
  prefix_cnt=$(echo ${prefix} | grep -o 1 | wc -l)
  echo $prefix_cnt
}

mask2cdr() {
  if [ -z "$1" ]; then
    return -1
  fi
  # Assumes there's no "255." after a non-255 byte in the mask
  local x=${1##*255.}
  set -- 0^^^128^192^224^240^248^252^254^ $(((${#1} - ${#x}) * 2)) ${x%%.*}
  x=${1%%$3*}
  echo $(($2 + (${#x} / 4)))
}

cdr2mask() {
  if [ -z "$1" ]; then
    return -1
  fi
  # Number of args to shift, 255..255, first non-255 byte, zeroes
  set -- $((5 - ($1 / 8))) 255 255 255 255 $(((255 << (8 - ($1 % 8))) & 255)) 0 0 0
  [ $1 -gt 1 ] && shift $1 || shift
  echo ${1-0}.${2-0}.${3-0}.${4-0}
}

ip_addr_flush() {
  local ifname
  config_get ifname $1 ifname
  if [ -n "ifname" ]; then
    hc_exec "ip a flush dev $ifname"
  fi
  hc_exec "ip link set dev $ifname up"
}

ip_addr_add() {
  local Enable
  local ifname
  local IPInterfaceIPAddress
  local IPInterfaceSubnetMask
  local IPInterfaceAddressingType
  local X_CU_IPv6Address_LocalAddress

  config_get IPInterfaceAddressingType $1 IPInterfaceAddressingType
  if [ "$IPInterfaceAddressingType" != "Static" ]; then
    return 0
  fi
  config_get Enable $1 Enable
  if [ "$Enable" != "1" ]; then
    return 0
  fi
  config_get ifname $1 ifname
  config_get IPInterfaceIPAddress $1 IPInterfaceIPAddress
  config_get IPInterfaceSubnetMask $1 IPInterfaceSubnetMask
  config_get X_CU_IPv6Address_LocalAddress $1 X_CU_IPv6Address_LocalAddress
  if [ -n "$IPInterfaceIPAddress" ] && [ -n "IPInterfaceSubnetMask" ]; then
    hc_exec "ip addr add $IPInterfaceIPAddress/"$(mask_to_prefix $IPInterfaceSubnetMask)" dev $ifname"
    ret $?
  fi

  if [ -n "$X_CU_IPv6Address_LocalAddress" ]; then
    hc_exec "ip -6 addr add ${X_CU_IPv6Address_LocalAddress}/64 dev $ifname"
  fi
}

addr_load_lan() {
  config_load 'network'
  config_foreach ip_addr_flush 'lan'
  config_foreach ip_addr_add 'lan1_ip'
}

#$1: package_name
#$2: config_name
addr_status_wan() {
  local ifnames="$(uci_get $1 $2 ifnames)"
  local instance="$(uci_get $1 $2 instance_num)"
  local access_type="$(uci_get $1 $2 WANAccessType)"
  local ipv4_ip
  local APN
  #清空所有wan${instance}_conn type section
  local i=0
  while :; do
    let 'i+=1'
    uci_remove $1 "@wan${instance}_conn[0]" &>/dev/null
    if [ $? == 1 ] || [ "$i" == "10" ]; then
      break
    fi
  done
  OLD_IFS="$IFS"
  IFS=','
  arr=($ifnames)
  IFS=$OLD_IFS
  i=0
  for ifname in ${arr[@]}; do
    let 'i+=1'
    uci_add $1 wan${instance}_conn
    uci_set $1 "@wan${instance}_conn[-1]" 'instance_num' ${i}
    uci_set $1 "@wan${instance}_conn[-1]" 'ifname' $ifname
    ipv4_ip=$(ip addr show dev $ifname 2>/dev/null | awk '$1 == "inet" {print $2}')
    if [ "$access_type" == "X_CU_5GNR" ]; then
      APN=$($AT_CLIENT 'at+cgdcont?' | awk -F, '$0~/CGDCONT: '"${i}"',/{print $3}' | sed 's/\"//g')
      uci_set $1 "@wan${instance}_conn[-1]" 'APN' $APN
    fi

    if [ -z "$ipv4_ip" ]; then
      uci_set $1 "@wan${instance}_conn[-1]" 'Enable' '0'
      continue
    fi
    uci_set $1 "@wan${instance}_conn[-1]" 'Enable' '1'
    uci_set $1 "@wan${instance}_conn[-1]" 'NATEnabled' '1'
    uci_set $1 "@wan${instance}_conn[-1]" 'IPAddress' "${ipv4_ip%/*}"
    uci_set $1 "@wan${instance}_conn[-1]" 'SubnetMask' "$(cdr2mask ${ipv4_ip##*/})"
  done
}

#$1: package_name
#$2: config_name
#lan不支持多ip
addr_status_lan() {
  local instance="$(uci_get $1 $2 instance_num)"
  local ifname="$(uci_get $1 $2 ifname)"
  local ipv4_ip
  local ipv6_ip
  i=0
  while :; do
    let 'i+=1'
    uci_remove $1 "@lan${instance}_ip[0]" &>/dev/null
    if [ $? == 1 ] || [ "$i" == "10" ]; then
      break
    fi
  done

  uci_add $1 lan${instance}_ip
  uci_set $1 "@lan${instance}_ip[-1]" 'instance_num' '1'
  uci_set $1 "@lan${instance}_ip[-1]" 'ifname' ${ifname}
  #只取第一个IP
  ipv4_ip=$(ip addr show dev $ifname 2>/dev/null | awk '$1 == "inet" {print $2}' | xargs | awk '{print $1}')
  if [ -z "$ipv4_ip" ]; then
    uci_set $1 "@lan${instance}_ip[-1]" 'Enable' '0'
  fi
  uci_set $1 "@lan${instance}_ip[-1]" 'Enable' '1'
  uci_set $1 "@lan${instance}_ip[-1]" 'IPInterfaceAddressingType' 'Static'
  uci_set $1 "@lan${instance}_ip[-1]" 'IPInterfaceIPAddress' "${ipv4_ip%/*}"
  uci_set $1 "@lan${instance}_ip[-1]" 'IPInterfaceSubnetMask' "$(cdr2mask ${ipv4_ip##*/})"
  ipv6_ip=$(ip addr show dev $ifname 2>/dev/null | awk '$1 == "inet6" && $4 == "link" {print $2}')
  if [ -n "$ipv6_ip" ]; then
    uci_set $1 "@lan${instance}_ip[-1]" 'X_CU_IPv6Address_LocalAddress' "${ipv6_ip%/*}"
  fi
}

#$1: package_name
#$2: config_name
A5G10_ipv6_prefix_status() {
  local instance="$(uci_get $1 $2 instance_num)"
  local info=$($AT_CLIENT 'at+gtrndis?' | awk '$0~/GTRNDIS: 1,'"${instance}"',/{print $2}')
  local ipv6_prefix=$(echo $info | awk -F, '{print $4}' | awk -F: '{print $1":"$2":"$3":"$4"::/64"}')
  i=0
  while :; do
    let 'i+=1'
    uci_remove $1 "@lan${instance}_ipv6_prefix[0]" &>/dev/null
    if [ $? == 1 ] || [ "$i" == "10" ]; then
      break
    fi
  done
  uci_add $1 lan${instance}_ipv6_prefix
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'instance_num' '1'
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'Mode' 'WANDelegated'
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'PreferredLifeTime' '4294967295'
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'Prefix' $ipv6_prefix
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'ValidLifeTime' '4294967295'
  uci_set $1 "@lan${instance}_ipv6_prefix[-1]" 'WANConnection' $instance
}

#$1: package_name
#$2: config_name
A5G10_ipv6_dns_status() {
  local instance="$(uci_get $1 $2 instance_num)"
  local info=$($AT_CLIENT 'at+gtrndis?' | awk '$0~/GTRNDIS: 1,'"${instance}"',/{print $2}')
  local ipv6_dns=$(echo $info | awk -F, '{print $6","$8}' | sed 's/\"//g')
  i=0
  while :; do
    let 'i+=1'
    uci_remove $1 "@lan${instance}_ipv6_dns[0]" &>/dev/null
    if [ $? == 1 ] || [ "$i" == "10" ]; then
      break
    fi
  done
  uci_add $1 lan${instance}_ipv6_dns
  uci_set $1 "@lan${instance}_ipv6_dns[-1]" 'instance_num' '1'
  uci_set $1 "@lan${instance}_ipv6_dns[-1]" 'DomainName' 'm.fxltsbl.com'
  uci_set $1 "@lan${instance}_ipv6_dns[-1]" 'IPv6DNSConfigType' 'WANConnection'
  uci_set $1 "@lan${instance}_ipv6_dns[-1]" 'IPv6DNSServers' $ipv6_dns
  uci_set $1 "@lan${instance}_ipv6_dns[-1]" 'WANConnection' $instance
}

typeset -l device
device="$(uci_get system @devinfo[0] InternalModelName)"
case $1 in
'addr')
  case $2 in
  'load')
    case $3 in
    'wan') ;;

    'lan')
      addr_load_lan
      ;;
    *)
      echo '{wan|lan}'
      ;;
    esac
    ;;
  'status')
    #load 反向操作，讲当前系统的实际配置同步到uci配置中
    case $3 in
    'wan')
      addr_status_wan 'network' '@wan[0]'
      ;;
    'lan')
      addr_status_lan 'network' '@lan[0]'
      ;;
    'ipv6_prefix')
      if [ "$device" == "a5g10" ]; then
        A5G10_ipv6_prefix_status 'network' '@lan[0]'
      fi
      ;;
    'ipv6_dns')
      if [ "$device" == "a5g10" ]; then
        A5G10_ipv6_dns_status 'network' '@lan[0]'
      fi
      ;;
    *)
      echo '{wan|lan|ipv6_prefix|ipv6_dns}'
      ;;
    esac
    uci_commit 'network'
    ;;
  *)
    echo '{load|status}'
    ;;
  esac
  ;;
*)
  echo "ip.sh {addr}"
  ;;
esac

_exit
