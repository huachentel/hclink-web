#!/bin/bash
#set -x
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

handle_action() {
  local rc=0
  local cmd
  local cmd_revert
  local key
  echo "" >$REVERT_CMD_TMP_FILE
  if [ -f "$CMD_TMP_FILE" ]; then
    #line eg. key=cmd<delim>revert-cmd
    while read line; do
      [ -z "$line" ] && continue
      key=${line%%=*}
      value=${line##*=}
      cmd=${value%%<delim>*}
      #cmd=${cmd##*=}
      [ -z "$cmd" ] && continue

      cmd_revert=${value##*<delim>}
      echo $cmd_revert >>$REVERT_CMD_TMP_FILE
      echo "run $cmd"
      $cmd
      rc=$?
      ret $rc
      if [ "$rc" != "0" ]; then
        break
      fi
    done <$CMD_TMP_FILE
    #revert when err
    line=""
    if [ "$rc" != "0" ]; then
      if [ -f $REVERT_CMD_TMP_FILE ]; then
        echo 'uci revert'
        rm -rf ${UCI_CONFIG_TMP_DIR}/*
        while read line; do
          [ -z "$line" ] && continue
          echo "run $line"
          $line
        done <$REVERT_CMD_TMP_FILE
      fi
    fi
    rm -rf $CMD_TMP_FILE
  fi
}

handle_action
_exit
