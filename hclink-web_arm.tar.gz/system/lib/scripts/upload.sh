#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

LOG_DIR="${DATA_ROOT}/log"
dir_check $LOG_DIR

upload() {
  local url="$(uci_get upload 1 URL)"
  local file_type="$(uci_get upload 1 FileType)"
  local user_name="$(uci_get upload 1 Username)"
  local password="$(uci_get upload 1 Password)"
  local start_time="$(uci_get upload 1 StartTime)"
  local command_key="$(uci_get upload 1 CommandKey)"
  local is_ftp="0"
  local upload_file=""
  local sn="$(uci_get system @devinfo[0] SerialNumber)"

  echo "URL=$url"
  echo "FileType=$file_type"
  echo "Username=$user_name"
  echo "Password=$password"
  echo "StartTime=$start_time"
  echo "CommandKey=$command_key"

  local up_url="$url"
  case "$url" in
  ftp://*)
    #echo "url is ftp" 1>&2
    is_ftp="1"
    ;;
  *)
    #echo "url is not ftp" 1>&2
    is_ftp="0"
    ;;
  esac

  case "$file_type" in
  *"Log"*)
    upload_file=${DATA_ROOT}/tmp/${sn}.log.tar.gz
    rm -rf $upload_file &>/dev/null
    tar -czvf ${upload_file} -C $DATA_ROOT log &>/dev/null
    ;;
  *)
    #echo "unknow type $file_type" 1>&2
    echo 'fault_code=-39001'
    exit 1
    ;;
  esac

  #case ftp
  if [ "$is_ftp" == "1" ]; then
    if [ "$user_name" != "" ]; then
      #echo "ftp upload with username" 1>&2
      curl --user $user_name:$password --connect-timeout 30 --upload-file $upload_file $up_url &>/dev/null
    else
      #echo "ftp upload without username" 1>&2
      curl -T --connect-timeout 30 $upload_file $up_url &>/dev/null
    fi
    fault_code="$?"
  else
    auth_base64=$(echo -n "${user_name}:${password}" | base64)
    curl -k -X POST $up_url -H "Authorization:Basic $auth_base64" -H 'cache-control: no-cache' \
      -H 'content-type: multipart/form-data;' \
      -F "object={\"name\":\"${upload_file##*/}\",\"type\":\"application/octet-stream\", \"serialNumber\" : \"$sn\"}" \
      -F file=@/${upload_file} &>/dev/null
    fault_code="$?"
  fi
  rm -rf $upload_file &>/dev/null

  if [ "$fault_code" != "0" ]; then
    echo 'fault_code=-39011'
    exit 1
  else
    echo 'fault_code=0'
    exit 0
  fi
}
#echo "start upload" 1>&2
upload
