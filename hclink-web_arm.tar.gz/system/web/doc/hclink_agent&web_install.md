# web前后端编译安装及部署

## 概述

### 目的

1. 已出厂的部分设备有安装web功能的需求，为安装包部署提共参考

2. 为后端开发人员提供环境搭建步骤

3. 为测试人员提供环境部署，打包，安装步骤

### 适用范围

安装ubuntu18.04系统的arm/x86设备

### 修改记录

*版本* | *日期* | *作者* |　*说明*
-|-|-|-
v1.0 | 2020/11/27 |陈辉| 创建文档

## 源码目录说明

```text
├── depends //一些相关依赖的源码
│   ├── mqtt
│   ├── goahead
│   └── uci
├── fs
│   ├── recovery //系统升级,重置相关
│   └── system
│       ├── bin　//编译安装位置
│       ├── etc
│       │   └── config　//初始配置
│       └── lib
│           ├── scripts　//src 引用到的脚本
│           └── systemd　//systemctl 启动服务配置
├── src  //agent源码
├── test //测试脚步及相关json等
└── tools
    └── web_cgi
```

## 依赖安装

若缺失编译环境，以下命令安装

```bash
apt install build-essential -y
```

安装uci, mqtt, goahead

```bash
cd fs
./ubuntu_build.sh depends
```

检查系统是否安装atcmdtool

```bash
which atcmdtool
```

若不存在则手动编译安装，源码位置:depends/atcmdtool

*备注, 依赖只需安装一次接口，不用重复安装*

## 编译agent

```bash
cd fs
./ubuntu_build.sh agent
```

## 安装web

当前还未自己编译web，先从测试服务器上复制已经编译好的web目录到fs/system/web

## 编译安装cgi

```bash
cd tools/web_cgi
make
chmod a+x sys-config
cp sys-config /fs/system/web/cgi-bin
```

## 打包

```bash
cd fs
./ubuntu_build.sh def <version> upgrade
```

## 安装

打包后的part1.tar.gz适用于同架构设备

```bash
cd fs
rm -rf /hclink/*
mkdir /data
tar -xvf part1.tar.gz -C /hclink
/hclink/setup/ubuntu_setup.sh reinstall

cat /etc/hosts
127.0.0.1 localhost  default
#/etc/hosts 应包含如上所示内容, 不存在则需要添加

reboot
```

## 测试web

1. pc 接入设备网口，网段设为一致
2. 浏览器输入IP:8848　访问页面

## 升级更新

暂未调试
