#include "dm_init.h"

void dm_init()
{
  ENTRY_INIT(ROOT);
  ENTRY_INIT(DeviceInfo);
  ENTRY_INIT(IPPingDiagnostics);
  ENTRY_INIT(ManagementServer);
  ENTRY_INIT(Layer3Forwarding);
  ENTRY_INIT(Log);
  ENTRY_INIT(LANDevice);
  ENTRY_INIT(LAN1_WLANConfig);
  ENTRY_INIT(WANDevice_5GNR_1);

  /*dm2*/
  ENTRY_INIT(CPE_RunInfo);
  ENTRY_INIT(CPE_WANInterface);
  ENTRY_INIT(CPE_LANDevice);
  ENTRY_INIT(CPE_IPv4DefaultRoute);
  ENTRY_INIT(CPE_DHCPv4);
  ENTRY_INIT(CPE_WAN5GNR);
  ENTRY_INIT(CPE_WLANConfiguration);
  ENTRY_INIT(CPE_GeneralStatus);
  ENTRY_INIT(CPE_Log_Alarm);
  ENTRY_INIT(CPE_ACL);
}

void run_only_once_func_on()
{
  FUNC_RUN_ONCE_FLAG_SET(get_l3forward_info);
  FUNC_RUN_ONCE_FLAG_SET(get_lan_ip_status);

  FUNC_RUN_ONCE_FLAG_SET(get_nr5g_status);
  FUNC_RUN_ONCE_FLAG_SET(get_nr5g_sim_status);
  FUNC_RUN_ONCE_FLAG_SET(get_nr5g_location_status);
  FUNC_RUN_ONCE_FLAG_SET(get_wan_status);
  FUNC_RUN_ONCE_FLAG_SET(get_wan1_conn1_dnat_status);

  /*dm2*/
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_wan_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_lan_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_ipv4_default_route);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_nr5g_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_nr5g_sim_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_cpe_acl_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_nr5g_conn_status);
  FUNC_RUN_ONCE_FLAG_SET(dm2_get_nr5g_lock_status);
}

/*添加系统监控*/
void individual_system_monitor()
{
  wan_link_check();
  DBG("individual system monitor");
}