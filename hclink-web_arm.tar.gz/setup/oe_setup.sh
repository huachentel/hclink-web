#/bin/sh
CONFIG_DIR=AMB_2

file_install_without_recovery() {
  if [ ! -f '/bin/bash' ]; then
    ln -v -s /hclink/system/bin/bash /bin/bash
  fi

  if [ ! -f '/etc/localtime' ]; then
    ln -v -s /hclink/system/share/zoneinfo/Asia/Shanghai /etc/localtime
  fi

  host_info="$(cat /etc/hosts | grep sdxprairie)"
  if [ -z "$host_info" ]; then
    echo '127.0.0.1 sdxprairie' >>/etc/hosts
  fi

  if [ ! -d /data/hclink ]; then
    mkdir -v /data/hclink
  fi
  mkdir -v /data/hclink/tmp
  mkdir -v /data/hclink/log
  mkdir -v /data/hclink/etc
  mkdir -v /data/hclink/var
  echo 1 >/data/hclink/var/NR
  echo 0 >/data/hclink/var/update
  echo 1 >/data/hclink/var/auto_connect
  mkdir /data/hclink/etc/config
  cp -rv /hclink/system/etc/config/${CONFIG_DIR}/* /data/hclink/etc/config
  cp -rv /hclink/system/etc/*.conf /data/hclink/etc
  cp -rv /hclink/system/etc/*.xml /data/hclink/etc
  chown -R root:root /hclink
  ln -v -s /hclink/system/lib/libuci.so /usr/lib/libuci.so

  #selinux
  chcon -R -t default_t /hclink
  chcon -R -t lib_t /hclink/system/lib
  chcon -R -t bin_t /hclink/system/bin
  chcon -t fibo_app_platform_exec_t /hclink/system/bin/hclink_agent
  chcon -t fibo_app_platform_exec_t /hclink/system/bin/hclink_at_server
  chcon -t bin_t /bin/bash
}

hclink_install() {
  file_install_without_recovery
  #recovery
  mkdir -v /data/hclink/recovery
  mkdir -v /data/hclink/recovery/image
  mkdir -v /data/hclink/recovery/log
  mkdir -v /data/hclink/recovery/new
  mkdir -v /data/hclink/recovery/scripts

  cp -rv /hclink/recovery/scripts/oe/*.sh /data/hclink/recovery/scripts/
  #rm -rvf /hclink/recovery
  #systemd
  cp -v /hclink/system/lib/systemd/system/oe/*.service /lib/systemd/system/

  systemctl enable hclink_at_server
  systemctl enable hclink_agent_server
  systemctl enable hclink_ntpd
  #web
  systemctl enable hclink_init
  systemctl enable hclink_reset
  systemctl enable hclink_speed
  systemctl enable hclink_web
  #systemctl enable hclink_agent_upgrade
}

remove_old_file_without_recovery() {
  if [ -f '/bin/bash' ]; then
    rm -rvf '/bin/bash'
  fi
  if [ -f '/etc/localtime' ]; then
    rm -rvf '/etc/localtime'
  fi
  if [ -f '/usr/lib/libuci.so' ]; then
    rm -rvf '/usr/lib/libuci.so'
  fi
  #recovery文件夹保留
  if [ -d /data/hclink ]; then
    ls /data/hclink/ | sed "s:^:/data/hclink/:" | grep -v recovery | xargs rm -rvf
  fi
}

hclink_uninstall() {
  remove_old_file_without_recovery
  rm -rvf /data/hclink/*

  # systemctl stop hclink_at_server
  # systemctl stop hclink_agent_server
  # systemctl stop hclink_ntpd
  ls /etc/systemd/system/multi-user.target.wants | grep hclink_ | xargs systemctl stop

  # systemctl disable hclink_at_server
  # systemctl disable hclink_agent_server
  # systemctl disable hclink_ntpd
  ls /etc/systemd/system/multi-user.target.wants | grep hclink_ | xargs systemctl disable

  rm -rvf /lib/systemd/system/hclink*
  sleep 1
}

hclink_clean() {
  cd /hclink
  rm -rvf *
  cd /data/hclink_system
  rm -rvf *
  cd /data/hclink_tar
  rm -rvf *

  rm -rf /data/fibo_upgrade_delta.zip
  rm -rf /data/recovery
}

hclink_upgrade() {
  remove_old_file_without_recovery
  file_install_without_recovery
}

hclink_tar() {
  mkdir /data/hclink_tar
  cd /data/hclink_tar
  rm -rvf hclink_${1}_root.tar.gz
  rm -rvf hclink_${1}_data.tar.gz

  tar -czvpf hclink_${1}_root.tar.gz /hclink \
    /bin/bash \
    /etc/systemd/system/multi-user.target.wants/hclink_* \
    /etc/localtime \
    /etc/hosts \
    /lib/systemd/system/hclink*

  tar -czvpf hclink_${1}_data.tar.gz /data/hclink /data/hclink_system
}

setenforce 0
case $1 in
'install')
  mount -o remount rw /
  hclink_install
  sync
  umount /
  ;;
'uninstall')
  mount -o remount rw /
  hclink_uninstall
  sync
  umount /
  ;;
'reinstall')
  mount -o remount rw /
  hclink_uninstall
  hclink_install
  sync
  umount /
  ;;
'clean')
  mount -o remount rw /
  hclink_clean
  ;;
'upgrade')
  mount -o remount rw /
  hclink_upgrade
  sync
  umount /
  ;;
'tar')
  if [ -z "$2" ]; then
    echo "need version info"
    exit 0
  fi
  mount -o remount rw /
  hclink_tar $2
  sync
  umount /
  ;;
*)
  echo "{install|uninstall|clean|reinstall|upgrade|tar}"
  ;;
esac
setenforce 1
