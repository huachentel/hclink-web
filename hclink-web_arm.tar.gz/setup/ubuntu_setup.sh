#/bin/sh
CONFIG_DIR=AMB_2

file_install_without_recovery() {
  if [ ! -d /data/hclink ]; then
    mkdir -v /data/hclink
  fi
  mkdir -v /data/hclink/tmp
  mkdir -v /data/hclink/log
  mkdir -v /data/hclink/etc
  mkdir -v /data/hclink/var
  #cp -rv /hclink/system/etc/*  /data/hclink/etc
  mkdir -v /data/hclink/etc/config
  cp -rv /hclink/system/etc/config/${CONFIG_DIR}/* /data/hclink/etc/config
  chown -R root:root /hclink
  cp -rv /hclink/system/bin/atcmdtool /usr/local/bin
}

hclink_install() {
  file_install_without_recovery
  #recovery
  mkdir -v /data/hclink/recovery
  mkdir -v /data/hclink/recovery/image
  mkdir -v /data/hclink/recovery/log
  mkdir -v /data/hclink/recovery/new
  mkdir -v /data/hclink/recovery/scripts

  cp -rv /hclink/recovery/scripts/ubuntu/*.sh /data/hclink/recovery/scripts/
  #rm -rvf /hclink/recovery
  #systemd
  cp -v /hclink/system/lib/systemd/system/ubuntu/*.service /lib/systemd/system/

  systemctl enable hclink_agent_server
  systemctl enable hclink_web
  systemctl enable hclink_ttyd
}

remove_old_file_without_recovery() {
  #recovery文件夹保留
  if [ -d /data/hclink ]; then
    ls /data/hclink/ | sed "s:^:/data/hclink/:" | grep -v recovery | xargs rm -rvf
  fi
}

hclink_uninstall() {
  remove_old_file_without_recovery
  rm -rvf /data/hclink/*

  ls /etc/systemd/system/multi-user.target.wants | grep hclink_ | xargs systemctl stop

  ls /etc/systemd/system/multi-user.target.wants | grep hclink_ | xargs systemctl disable

  rm -rvf /lib/systemd/system/hclink*
  sleep 1
}

hclink_clean() {
  cd /hclink
  rm -rvf *
  cd /data/hclink_system
  rm -rvf *
  cd /data/hclink_tar
  rm -rvf *

  rm -rf /data/fibo_upgrade_delta.zip
  rm -rf /data/recovery
}

hclink_upgrade() {
  remove_old_file_without_recovery
  file_install_without_recovery
}

hclink_tar() {
  mkdir /data/hclink_tar
  cd /data/hclink_tar
  rm -rvf hclink_${1}_root.tar.gz
  rm -rvf hclink_${1}_data.tar.gz

  tar -czvpf hclink_${1}_root.tar.gz /hclink \
    /bin/bash \
    /etc/systemd/system/multi-user.target.wants/hclink_* \
    /etc/localtime \
    /etc/hosts \
    /lib/systemd/system/hclink*

  tar -czvpf hclink_${1}_data.tar.gz /data/hclink /data/hclink_system
}

case $1 in
'install')
  hclink_install
  ;;
'uninstall')
  hclink_uninstall
  ;;
'reinstall')
  hclink_uninstall
  hclink_install
  ;;
'clean')
  hclink_clean
  ;;
'upgrade')
  hclink_upgrade
  ;;
'tar')
  if [ -z "$2" ]; then
    echo "need version info"
    exit 0
  fi
  hclink_tar $2
  ;;
*)
  echo "{install|uninstall|clean|reinstall|upgrade|tar}"
  ;;
esac
sync
