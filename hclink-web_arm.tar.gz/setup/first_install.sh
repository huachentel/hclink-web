#!/bin/sh

cd /data/hclink_tar
tar -xvf part1.tar.gz -C /hclink
tar -xvf part2.tar.gz -C /data/hclink_system
cd /hclink/
./setup/oe_setup.sh reinstall
