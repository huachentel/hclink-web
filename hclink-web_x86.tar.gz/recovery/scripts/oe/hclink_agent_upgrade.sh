#!/bin/sh
PREFIX="/data/hclink/recovery"
INSTALL_PART1_PATH="/hclink"
INSTALL_PART2_PATH="/data/hclink_system"
INSTALL_SCRIPT="/hclink/setup/oe_setup.sh"
SCRIPTS_PATH="${PREFIX}/scripts"
NEW_IMAGE_PATH="${PREFIX}/new"
IMAGE_PATH="${PREFIX}/image"
STATUS_FILE="${PREFIX}/status"
LOG_PATH="${PREFIX}/log"
#status:
#   "updating"
#   "updating_success"
#   "image_error"

log() {
  if [ "$1" == '-n' ]; then #whithout \n
    shift
    echo -n [$(date "+%Y-%m-%d %H:%M:%S") upgrade.sh]: $@ >>$LOG_PATH/upgrade.log
  elif [ "$1" == '-a' ]; then #append
    shift
    echo $@ >>$LOG_PATH/upgrade.log
  else
    echo [$(date "+%Y-%m-%d %H:%M:%S") upgrade.sh]: $@ >>$LOG_PATH/upgrade.log
  fi
}

do_upgrade() {
  if [ -f "${NEW_IMAGE_PATH}/upgrade.file" ]; then
    log -n "tar -xvf upgrade.file to $NEW_IMAGE_PATH ... "
    tar -xvf ${NEW_IMAGE_PATH}/upgrade.file -C $NEW_IMAGE_PATH
    if [ "$?" == "0" ]; then
      log -a "done"
    else
      log -a "error"
      echo "internal_error" >$STATUS_FILE
      return 1
    fi

    #install part1
    log -n "install part1.tar.gz to $INSTALL_PART1_PATH ... "
    rm -rf ${INSTALL_PART1_PATH}/*
    tar -xvf ${NEW_IMAGE_PATH}/part1.tar.gz -C $INSTALL_PART1_PATH
    if [ "$?" == "0" ]; then
      log -a "done"
    else
      log -a "error"
      echo "internal_error" >$STATUS_FILE
      return 1
    fi

    #install part2
    log -n "install part2.tar.gz to $INSTALL_PART2_PATH ... "
    if [ ! -d $INSTALL_PART2_PATH ]; then
      mkdir $INSTALL_PART2_PATH
    fi
    rm -rf ${INSTALL_PART2_PATH}/*
    tar -xvf ${NEW_IMAGE_PATH}/part2.tar.gz -C $INSTALL_PART2_PATH
    if [ "$?" == "0" ]; then
      log -a "done"
    else
      log -a "error"
      echo "internal_error" >$STATUS_FILE
      return 1
    fi

    echo 'updating_success' >$STATUS_FILE
    log -a "done"

    log -n "deleting upgrade file in ${NEW_IMAGE_PATH} ... "
    rm -rf ${NEW_IMAGE_PATH}/*
    log -a "done"

    #执行安装脚本
    cp ${INSTALL_SCRIPT} ${SCRIPTS_PATH}
    log "run ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/}"
    ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/} upgrade >>$LOG_PATH/upgrade.log
    rm -rf ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/}
    log "upgrade success!"
    return 0
  else
    log "ERR: missing upgrade file"
    echo "image_error" >$STATUS_FILE
    return 1
  fi
}

do_fibo_upgrade() {
  log "do fibo upgrade stage2"
  cp ${INSTALL_SCRIPT} ${SCRIPTS_PATH}
  log "run ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/}"
  ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/} upgrade >>$LOG_PATH/upgrade.log
  rm -rf ${SCRIPTS_PATH}/${INSTALL_SCRIPT##*/}
  log "upgrade success!"
  return 0
}

upgrade_stage2() {
  local status

  echo "" >${LOG_PATH}/upgrade.log

  if [ -f $STATUS_FILE ]; then
    status="$(cat $STATUS_FILE)"
  fi

  if [ "$status" == "updating" ]; then
    log "Start upgrading"
    mount -o remount rw /
    do_upgrade
    umount /
    return $?
  fi

  if [ "$status" == "fibo_updating" ]; then
    mount -o remount rw /
    do_fibo_upgrade
    umount /
    return $?
  fi

  log "do nothing"
  return 0
}

setenforce 0
cp $LOG_PATH/upgrade.log $LOG_PATH/upgrade.log.bck
upgrade_stage2
#setenforce 1
