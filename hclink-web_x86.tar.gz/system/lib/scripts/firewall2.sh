#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

ACL_CONFIG_FILE="firewall2_acl"
ACL_TMP_FILE="$DATA_ROOT/tmp/acl.tmp"

acl_status() {
  #pkts bytes target prot opt in out source destination
  iptables -L INPUT -nv | awk '$3=="DROP" || $3=="ACCEPT"  {print  $0}' >$ACL_TMP_FILE
  i=1

  #clean
  while :; do
    uci_remove $ACL_CONFIG_FILE "@rule[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
  #get
  while read line; do
    [ -z "$line" ] && continue
    SrcIP="$(echo "$line" | awk '{print $8}')"
    DstIP="$(echo "$line" | awk '{print $9}')"
    SrcPort="$(echo "$line" | awk '{print $11}' | awk -F: '$1=="spt"  {print $2}')"
    DstPort="$(echo "$line" | awk '{print $11}' | awk -F: '$1=="dpt"  {print $2}')"
    Protocol="$(echo "$line" | awk '{print $4}')"

    uci_add $ACL_CONFIG_FILE "rule" $i
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'instance_num' $i
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'SrcIP' $SrcIP
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'DstIP' $DstIP
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'SrcPort' $SrcPort
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'DstPort' $DstPort
    uci_set $ACL_CONFIG_FILE "@rule[-1]" 'Protocol' $Protocol
    let 'i+=1'
  done <$ACL_TMP_FILE
}

#$1 instance num
#TODO 忽略特定规则，如某些端口号需要一直打开
acl_add() {
  local SrcIP
  local DstIP
  local SrcPort
  local DstPort
  local Protocol

  local is_tcp_udp

  if [ -z "$1" ]; then
    ret 1
    return 1
  fi

  SrcIP=$(uci_get $ACL_CONFIG_FILE $1 SrcIP)
  DstIP=$(uci_get $ACL_CONFIG_FILE $1 DstIP)
  SrcPort=$(uci_get $ACL_CONFIG_FILE $1 SrcPort)
  DstPort=$(uci_get $ACL_CONFIG_FILE $1 DstPort)
  Protocol=$(uci_get $ACL_CONFIG_FILE $1 Protocol)

  if [ -z "$SrcIP" ] && [ -z "$DstIP" ] && [ -z "$SrcPort" ] && [ -z "$DstPort" ]; then
    #不允许丢弃全部
    if [ -z "$Protocol" ] || [ "$Protocol" == "all" ]; then
      ret 1
      return 1
    fi
  fi

  if [ "$Protocol" == 'tcp' ] || ["$Protocol" == 'udp' ]; then
    is_tcp_udp=1
  fi

  iptables -A INPUT ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    -j DROP
  ret $?
}

#删除指定的rule
acl_del() {
  local SrcIP
  local DstIP
  local SrcPort
  local DstPort
  local Protocol

  local is_tcp_udp

  if [ -z "$1" ]; then
    ret 1
    return 1
  fi

  #连续删除会导致序号发生变化，故不使用下面的方法
  #iptables -D INPUT $1

  SrcIP=$(uci_get $ACL_CONFIG_FILE $1 SrcIP)
  DstIP=$(uci_get $ACL_CONFIG_FILE $1 DstIP)
  SrcPort=$(uci_get $ACL_CONFIG_FILE $1 SrcPort)
  DstPort=$(uci_get $ACL_CONFIG_FILE $1 DstPort)
  Protocol=$(uci_get $ACL_CONFIG_FILE $1 Protocol)

  if [ "$Protocol" == 'tcp' ] || ["$Protocol" == 'udp' ]; then
    is_tcp_udp=1
  fi

  iptables -D INPUT ${Protocol:+ -p $Protocol} \
    ${SrcIP:+ -s $SrcIP} \
    ${is_tcp_udp:+ ${SrcPort:+ --sport $SrcPort} } \
    ${DstIP:+ -d $DstIP} \
    ${is_tcp_udp:+ ${DstPort:+ --dport $DstPort} } \
    -j DROP

  uci_remove $ACL_CONFIG_FILE $1
}

#清除所有规则
acl_flush() {
  iptables -F INPUT
  while :; do
    uci_remove $ACL_CONFIG_FILE "@rule[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
}

acl_config_get() {
  uci_get $ACL_CONFIG_FILE "@config[0]" &>/dev/null
  if [ "$?" != "0" ]; then
    uci_add $ACL_CONFIG_FILE "config"
  fi
  uci_set $ACL_CONFIG_FILE "@config[0]" 'instance_num' "1"
  uci_set $ACL_CONFIG_FILE "@config[0]" 'SSHEnable' "1"
  uci_set $ACL_CONFIG_FILE "@config[0]" 'Mode' "2"
  uci_set $ACL_CONFIG_FILE "@config[0]" 'TelnetEnable' "0"
}

#$1 对应config下的参数
acl_config_set() {
  local value

  value=$(uci_get $ACL_CONFIG_FILE "@config[0]" $1)
  case $1 in
  'SSHEnable')
    if [ "$value" == "1" ]; then
      echo 'ssh enable'
    else
      echo 'ssh disable'
    fi
    ;;
  'TelnetEnable')
    if [ "$value" == "1" ]; then
      echo 'telnet enable'
    else
      echo 'telnet disable'
    fi
    ;;
  'Mode') ;;

  'RuleClean')
    acl_flush
    ;;
  *)
    echo {'SSHEnable|TelnetEnable|Mode|RuleClean'}
    ;;
  esac
}

if [ ! -f ${DATA_ROOT}/etc/config/$ACL_CONFIG_FILE ]; then
  touch ${DATA_ROOT}/etc/config/$ACL_CONFIG_FILE
fi

case $1 in
'acl')
  case $2 in
  'status')
    acl_status
    uci_commit $ACL_CONFIG_FILE
    ;;
  'add')
    acl_add $3
    ;;
  'del')
    acl_del $3
    ;;
  'config')
    case $3 in
    'get')
      acl_config_get $4
      ;;
    'set')
      acl_config_set $4
      ;;
    *)
      echo '{get|set}'
      ;;
    esac
    ;;
  *)
    echo '{status|add|del|config}'
    ;;
  esac
  ;;
*)
  echo '{acl}'
  ;;
esac

_exit
