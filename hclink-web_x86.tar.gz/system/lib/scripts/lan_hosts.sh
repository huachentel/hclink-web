#!/bin/bash
#统计LAN测接入的用户设备

[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

LEASE_FILE=/var/run/data/dnsmasq.leases

# cat /var/lib/misc/dnsmasq.leases
# 1588257614 00:25:7c:30:05:f0 172.20.10.19 default *
# 1588266572 70:85:c2:36:b0:61 172.20.10.72 chenhui-pc *
lan_device_list=""
is_dhcp_host=0
i=0

#$1 section
#$2 arp map ipaddr
#$3 arp map active info
active_check() {
  local IPAddress
  local Active
  config_get IPAddress $1 IPAddress
  if [ "$IPAddress" == "$2" ]; then
    if [ "$3" == '0x2' ]; then
      uci_set 'lan_host' "$1" 'Active' '1'
    else
      uci_set 'lan_host' "$1" 'Active' '0'
    fi
    is_dhcp_host=1
  fi
}

#$1 lan_host section type
#$2 lan_host ection type instance num
#$3 IPAddress
#$4 AddressSource
#$5 MACAddress
#$6 HostName
#$7 LeaseTimeRemaining

add_host_log() {
  uci_add 'lan_host' ${1}
  uci_set 'lan_host' "@${1}[-1]" 'instance_num' $2
  uci_set 'lan_host' "@${1}[-1]" 'IPAddress' $3
  uci_set 'lan_host' "@${1}[-1]" 'AddressSource' $4
  uci_set 'lan_host' "@${1}[-1]" 'MACAddress' $5
  uci_set 'lan_host' "@${1}[-1]" 'HostName' $6
  uci_set 'lan_host' "@${1}[-1]" 'LeaseTimeRemaining' $7
}

#$1: lan instance
read_dhcp_leases() {
  local ifname
  local now_time
  local lease_time
  local time_remain
  local ipaddr
  local active
  local device
  local lease_num
  local lease_file_name

  #5G模组lease文件位置
  #--dhcp-leasefile=/var/run/data/dnsmasq.leases 对应LAN1
  #--dhcp-leasefile=/var/run/data/dnsmasq.leases.bridge1 对应LAN2
  lease_num=$1
  let lease_num--
  if [ "$lease_num" == "0" ]; then
    lease_file_name=$LEASE_FILE
  else
    lease_file_name=${LEASE_FILE}.bridge${lease_num}
  fi

  i=1
  while read msg; do
    [ -z "$msg" ] && continue
    now_time=$(date +%s)
    lease_time=$(echo "$msg" | awk '{print $1}')
    time_remain=$(($lease_time - $now_time))
    add_host_log "lan${1}_host" $i $(echo "$msg" | awk '{print $3}') 'DHCP' $(echo "$msg" | awk '{print $2}') $(echo "$msg" | awk '{print $4}') "$time_remain"
    let 'i+=1'
  done <$lease_file_name

  msg=""
  config_load 'lan_host'
  ifname=$(uci_get network @lan[$lease_num] ifname)
  while read msg; do
    ipaddr=$(echo "$msg" | awk '{print $1}')
    active=$(echo "$msg" | awk '{print $3}')
    device=$(echo "$msg" | awk '{print $6}')

    #查看device 是不是该lan接口的
    if [ "$ifname" == "$device" ]; then
      is_dhcp_host=0
      config_foreach active_check "lan${1}_host" $ipaddr $active
      #遍历dhcp lease 后发现不存在该ip, 则认为是static
      if [ "$is_dhcp_host" == "0" ]; then
        add_host_log "lan${1}_host" $i $ipaddr 'Static' $(echo "$msg" | awk '{print $4}') 'unknow' '0'
        let 'i+=1'
        if [ "$active" == '0x2' ]; then
          uci_set 'lan_host' "@lan${1}_host[-1]" 'Active' '1'
        else
          uci_set 'lan_host' "@lan${1}_host[-1]" 'Active' '0'
        fi
      fi
    fi
  done <'/proc/net/arp'
  uci_add 'lan_host' 'num'
  let 'i-=1'
  uci_set 'lan_host' '@num[-1]' 'HostNumberOfEntries' "$i"
  uci_set 'lan_host' '@num[-1]' 'instance_num' "1"
  #uci_commit  'lan_host'
}

#clean all log
echo "" >$UCI_CONFIG_DIR/lan_host
rm -rf $UCI_CONFIG_TMP_DIR/lan_host
read_dhcp_leases '1'
