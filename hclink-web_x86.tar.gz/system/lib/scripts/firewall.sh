#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

DNAT_TMP_FILE="$DATA_ROOT/tmp/dnat.tmp"

# $1 : wan instance_num
# $2 : wan connection instance num
dnat_status() {
  #get interface name
  wan_ins=$1
  conn_ins=$2
  let 'wan_ins-=1'
  ifnames="$(uci_get 'network' "@wan[${wan_ins}]" 'ifnames')"
  ifname="$(echo $ifnames | awk -F, '{print $"'"$conn_ins"'"}')"
  echo $ifname
  #pkts bytes target prot opt in out source destination
  iptables -t nat -L -nv | awk '$3=="DNAT" &&  ($6 == "'"$ifname"'" || $6 == "*" ) {print  $0}' >$DNAT_TMP_FILE
  i=1
  if [ ! -f ${DATA_ROOT}/etc/config/firewall ]; then
    touch ${DATA_ROOT}/etc/config/firewall
  fi
  #clean
  while :; do
    uci_remove 'firewall' "@wan${1}_conn${2}_dnat_status[0]" &>/dev/null
    if [ $? == 1 ]; then
      break
    fi
  done
  #get
  while read line; do
    [ -z "$line" ] && continue
    prot="$(echo "$line" | awk '{print $4}')"
    external_port="$(echo "$line" | awk '{print $11}' | awk -F: '{print $2}')"
    internal_port="$(echo "$line" | awk '{print $12}' | awk -F: '{print $3}')"
    internal_ip="$(echo "$line" | awk '{print $12}' | awk -F: '{print $2}')"

    uci_add 'firewall' "wan${1}_conn${2}_dnat_status"
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'instance_num' $i
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'PortMappingEnabled' '1'
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'ExternalPort' $external_port
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'InternalPort' $internal_port
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'PortMappingProtocol' $prot
    uci_set 'firewall' "@wan${1}_conn${2}_dnat_status[-1]" 'InternalClient' $internal_ip
    let 'i+=1'
  done <$DNAT_TMP_FILE
}

# $1 : wan instance_num
# $2 : wan connection instance num
# $3 : instance num
#根据 instance mun 提取出uci index num
index_get() {
  local i
  i=$(uci show firewall | grep "firewall.@wan$1_conn$2_dnat\[.\].instance_num=.$3." | awk -F[ '{print $2}' | awk -F] '{print $1}')
  echo $i
}

#将new中的更改合并到配置表
# $1 : wan instance_num
# $2 : wan connection instance num
# $3 : uci config index
# $4 : option name

update_option() {
  local data
  data=$(uci_get 'firewall' "@wan${1}_conn${2}_dnat_new[0]" $4)
  if [ -n "$data" ]; then
    uci_set 'firewall' "@wan${1}_conn${2}_dnat[$3]" "$4" "$data"
  fi
}

# $1 : wan instance_num
# $2 : wan connection instance num
dnat_add() {
  local i
  local uci_i
  local ExternalPort
  local InternalPort
  local PortMappingProtocol
  local InternalClient
  local PortMappingEnabled
  local proto1
  local proto2

  #将dnat_new　根据instance_num　合并到dnat
  while :; do
    i="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat_new[0]" 'instance_num')"
    if [ -n "$i" ]; then
      uci_i="$(index_get $1 $2 $i)"

      #del old
      ExternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'ExternalPort')"
      InternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'InternalPort')"
      PortMappingProtocol="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'PortMappingProtocol')"
      InternalClient="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'InternalClient')"

      proto1="$(echo $PortMappingProtocol | awk -F, '{print $1}')"
      proto2="$(echo $PortMappingProtocol | awk -F, '{print $2}')"
      if [ -n "$proto1" ]; then
        hc_exec "iptables -t nat -D PREROUTING -p $proto1 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
      fi
      if [ -n "$proto2" ]; then
        hc_exec "iptables -t nat -D PREROUTING -p $proto2 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
      fi

      #upgrade config
      update_option $1 $2 "$uci_i" 'ExternalPort'
      update_option $1 $2 "$uci_i" 'InternalPort'
      update_option $1 $2 "$uci_i" 'PortMappingProtocol'
      update_option $1 $2 "$uci_i" 'InternalClient'
      update_option $1 $2 "$uci_i" 'PortMappingEnabled'

      PortMappingEnabled="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'PortMappingEnabled')"
      if [ "$PortMappingEnabled" == "1" ]; then
        ExternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'ExternalPort')"
        InternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'InternalPort')"
        PortMappingProtocol="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'PortMappingProtocol')"
        InternalClient="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[${uci_i}]" 'InternalClient')"

        proto1="$(echo $PortMappingProtocol | awk -F, '{print $1}')"
        proto2="$(echo $PortMappingProtocol | awk -F, '{print $2}')"
        if [ -n "$proto1" ]; then
          hc_exec "iptables -t nat -A PREROUTING -p $proto1 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
          rc=$?
          ret rc
        fi
        if [ -n "$proto2" ]; then
          hc_exec "iptables -t nat -A PREROUTING -p $proto2 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
          rc=$?
          ret rc
        fi
      fi
    else
      break
    fi
    uci_remove 'firewall' "@wan${1}_conn${2}_dnat_new[0]" &>/dev/null
  done

}

# $1 : wan instance_num
# $2 : wan connection instance num
# $3 : dnat instance num
dnat_del() {
  local ExternalPort
  local InternalPort
  local PortMappingProtocol
  local InternalClient
  local i
  local uci_i

  i="$3"
  if [ -n "$i" ]; then
    echo i=$i
    uci_i="$(index_get $1 $2 $i)"
    echo uci_index=$uci_i
    if [ -n "$uci_i" ]; then
      ExternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[$uci_i]" 'ExternalPort')"
      InternalPort="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[$uci_i]" 'InternalPort')"
      PortMappingProtocol="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[$uci_i]" 'PortMappingProtocol')"
      InternalClient="$(uci_get 'firewall' "@wan${1}_conn${2}_dnat[$uci_i]" 'InternalClient')"

      proto1="$(echo $PortMappingProtocol | awk -F, '{print $1}')"
      proto2="$(echo $PortMappingProtocol | awk -F, '{print $2}')"
      if [ -n "$proto1" ]; then
        hc_exec "iptables -t nat -D PREROUTING -p $proto1 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
      fi
      if [ -n "$proto2" ]; then
        hc_exec "iptables -t nat -D PREROUTING -p $proto2 --dport $ExternalPort -j DNAT --to-des $InternalClient:$InternalPort"
      fi
      uci_remove 'firewall' "@wan${1}_conn${2}_dnat[$uci_i]"
    fi
  fi
}

case $1 in
'dnat')
  case $2 in
  'status')
    #$3 wan/lan instance num
    #$4 wan conn instance num
    dnat_status $3 $4
    uci_commit firewall
    ;;
  'add')
    dnat_add $3 $4
    ;;
  'del')
    #$5 dnat instance num
    dnat_del $3 $4 $5
    ;;
  *)
    echo '{status}'
    ;;
  esac
  ;;
*)
  echo '{dnat}'
  ;;
esac

_exit
