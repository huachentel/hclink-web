#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

if [ "$AGENT_SYSTEM" == "ubuntu" ]; then
  #检测目录
  CHECK_DIR='/'
  LINK_MAIN_IFACE='eth0'
else
  CHECK_DIR='/data'
fi

#小于此大小则报警，单位:字节
STORAGE_ALARM_LIMIT='5000'

storage_check() {
  dl_size=$(df | grep "${CHECK_DIR}$" | awk '{print $4;}')
  [ -n "$dl_size" ] && dl_size_byte=$((${dl_size} * 1024))
  if [ -n "$dl_size" -a "$dl_size_byte" -lt "$STORAGE_ALARM_LIMIT" ]; then
    return 2
  else
    return 0
  fi
}

# 检测WAN的UP DOWN　状态
# return 0: 未检测到
#        2: up
#        3: down
#
wan_link_check() {
  local link
  link=$(cat /sys/class/net/${LINK_MAIN_IFACE}/operstate)
  if [ "$link" == "up" ] || [ "$link" == "unknown" ]; then
    echo 'link up'
    return 2
  elif [ "$link" == "down" ]; then
    echo 'link down'
    return 3
  fi
  return 0
}

case $1 in
"storage")
  storage_check
  exit $?
  ;;
"wan_link")
  wan_link_check
  exit $?
  ;;
*) ;;

esac
