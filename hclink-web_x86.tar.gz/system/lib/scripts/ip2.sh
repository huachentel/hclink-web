#!/usr/bin/env bash
#=====================================================================
# COPYSTR: Copyright (c) 2020 By HuachenLink, All Rights Reserved.
# FLENAME: ip2.sh
# CONTACT: liudongguo@huachen.link
# CREATED: 2020-11-14 06:54:49
# LTSVERN: 0.1
# LTSUPDT: 2020-11-14 06:54:57
#=====================================================================
#adopter-for-new-data-to-update-into-uci-settings
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
source ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh &>/dev/null

CONFIG_FILE='network2'
IFACE_MODE_FILTER='lo\|virbr0\|virbr0-nic\|ip6tnl0\|ifb0\|ip_vti0\|teql0\|teql0\|dummy0\|sit0\|ip6gre0\|ifb1\|ip6_vti0\|tunl0\|gre0\|br.*\|gretap0\|erspan0'
IFACE_MODE_CONFIGABLE='^e((th|no)[0-9]$|np)|vti[0-9]+$|vxlan[0-9]+'

hcl.ip2() {
  local cfn=$CONFIG_FILE
  local cfp=${DATA_ROOT:-/data/hclink}/etc/config/$cfn
  local dhcpcfile='/etc/dnsmasq.conf'
  [ -e $cfp ] || touch $cfp

  _bakOldData() {
    # cp $cfp /opt/${cfn}.$obj
    local curSection="@${obj}[-1]"
    rm -f /opt/$obj.*.env 2>/dev/null
    while :; do
      local tmfile=/tmp/$obj
      uci show $cfn.$curSection 2>/dev/null | sed "s#'##g" >$tmfile
      local fstline=$(head -n1 $tmfile | sed 's#=.*#.#')
      local nic=$(awk -F'=' '/.InterfaceName=/{print $2}' $tmfile)
      [ "X$nic" != "X" ] && tail +2 $tmfile | sed "s#$fstline##g" >/opt/$obj.$nic.env
      uci_remove $cfn "$curSection" &>/dev/null
      [ $? -ne 0 ] && break
    done
  }
  #----------------------------------------------
  _getCurYml() {
    local cdir=/etc/netplan
    [ -d $cdir ] || mkdir -p $cdir
    local fstYml=$(cd $cdir && command ls *.yaml | xargs -n1 | head -1)
    if [ "X$fstYml" != "X" ]; then
      [ -e ${cdir}/${fstYml}.bak ] || mv $cdir/$fstYml{,.bak}
      rm -f $cdir/*.yaml 2>/dev/null
    else
      fstYml='00-hclink.yaml'
    fi
    echo $cdir/$fstYml
  }
  #----------------------------------------------
  _cdr2mask() {
    case $1 in
    -h | --help | help) echo 'Usage '$FUNCNAME' [CDR_NUM]' && return ;;
    8) echo '255.0.0.0' ;;
    16) echo '255.255.0.0' ;;
    24) echo '255.255.255.0' ;;
    *)
      local fs=$((5 - ($1 / 8)))
      local sfi=$(
        s1=$((8 - ($1 % 8)))
        echo $(((255 << $1) & 255))
      )
      set -- $fs 255 255 255 255 $sfi 0 0 0
      [ $1 -gt 1 ] && shift $1 || shift
      echo ${1-0}.${2-0}.${3-0}.${4-0}
      ;;
    esac
  }
  ##STATUS===========================================================
  _get() {
    _bakOldData
    local curSection="@${obj}[-1]" syi=
    if [ "X$obj" == "Xwan" ]; then
      for iface in $(command ls /sys/class/net | command grep -v $IFACE_MODE_FILTER); do
        syi=/sys/class/net/$iface
        [ -e $syi/master ] && continue
        #####create=======================================
        (
          uci_add $cfn $obj

          oldcfgfile=/opt/$obj.$iface.env
          [ -e $oldcfgfile ] && source $oldcfgfile

          isConfigable=0
          echo $iface | grep -Eq $IFACE_MODE_CONFIGABLE
          [ $? -eq 0 ] && isConfigable=1
          uci_set $cfn "$curSection" "ConfigEnable" ${ConfigEnable:-${isConfigable}}
          uci_set $cfn "$curSection" "IPInterfaceAddressingType" "${IPInterfaceAddressingType:-DHCP}"
          uci_set $cfn "$curSection" "SNATEnable" "${SNATEnable:-0}"
          curIP4=$(ip -4 a show $iface | awk '/inet /{print $2}')
          if [ "X$curIP4" != "X" ]; then
            curGW4=$(ip route show default | awk "/ dev $iface /" | awk '{print $3}')
            [ "X$curGW4" == "X" ] && curGW4=$IPv4Gateway
            if [ "X$curGW4" == "X" ]; then
              if [[ "X$iface" == "Xeth0" && "X${curIP4}" == "X58.56.57.123" ]]; then
                curGW4=${curIP4%.*}.121
              else
                curGW4=${curIP4%.*}.1
              fi
            fi
            ip route add default via $curGW4 dev $iface 2>/dev/null
          fi
          uci_set $cfn "$curSection" "IPv4Gateway" ${curGW4}
          uci_set $cfn "$curSection" "IPv4Address" "${curIP4}"
          uci_set $cfn "$curSection" "IPv4BackupDNS" "${IPv4BackupDNS:-114.114.114.114}"
          uci_set $cfn "$curSection" "IPv4DNS" "${IPv4DNS:-223.5.5.5}"
          uci_set $cfn "$curSection" "RouteMetric" $((100 * iNum))
          uci_set $cfn "$curSection" "MTU" $(cat $syi/mtu)
          uci_set $cfn "$curSection" "IPv6Address" $(ip -6 a show $iface | awk '$1 == inet6 && $4 == "link" {print $2}')
          uci_set $cfn "$curSection" "IPv6LocalAddress" $(ip -6 a show $iface | awk '/inet6 / && $4 != "link" {print $2}')
          uci_set $cfn "$curSection" "instance_num" "$iNum"
          uci_set $cfn "$curSection" "InterfaceName" "$iface"
          uci_set $cfn "$curSection" "Link" $(cat $syi/operstate)
          uci_set $cfn "$curSection" "MACAddress" $(cat $syi/address)
          # uci_set $cfn "$curSection" "IPv6BackupDNS"
          # uci_set $cfn "$curSection" "IPv6DNS"
          # uci_set $cfn "$curSection" "IPv6DNSType"
          # uci_set $cfn "$curSection" "IPv6Enable"
          # uci_set $cfn "$curSection" "IPv6Gateway"
          # uci_set $cfn "$curSection" "IPv6IPAddressingType"
        )
        ((iNum++))
      done
      rm -rf /opt/$obj.*.env 2>/dev/null
    else #===========================================================
      for iface in $(cd /sys/class/net && echo br-*); do
        syi=/sys/class/net/$iface
        [ -d "$syi/bridge" ] || continue
        uci_add $cfn 'lan'
        uci_set $cfn "$curSection" 'instance_num' $iNum
        uci_set $cfn "$curSection" 'InterfaceName' $iface
        uci_set $cfn "$curSection" 'MACAddress' $(cat $syi/address)
        uci_set $cfn "$curSection" 'MTU' $(cat $syi/mtu)
        uci_set $cfn "$curSection" 'PortInterface' $(cd $syi && echo lower_eth* | sed 's|lower_||g;s| |,|g')
        local dv4State=1
        local pid=$(pgrep dnsmasq | head -n1)
        [ "X$pid" == "X" ] && dv4State=0
        uci_set $cfn "$curSection" 'DHCPv4Enable' "$dv4State"
        uci_set $cfn "$curSection" 'DomainName' "www.example.com"
        uci_set $cfn "$curSection" 'DNSServers' "223.5.5.5"
        v4IP=$(ip -4 a show $iface | awk '/inet /{print $2}')
        if [ "X$v4IP" != "X" ]; then
          uci_set $cfn "$curSection" 'IPv4Address' $v4IP
          local rngMin=${v4IP%.*}.10 rngMax=${v4IP%.*}.180
          local lseTme="3600"
          local netMsk=$(
            t=${v4IP##*/}
            [ "X$t" == "X${v4IP}" ] && t=24
            _cdr2mask $t
          )
          if [ -e $dhcpcfile ]; then
            local items=($(awk -F'=' '/^dhcp-range=/{print $2}' $dhcpcfile | sed 's#,# #g'))
            if [ "X$items" != "X" ]; then
              rngMin=${items[0]}
              rngMax=${items[1]}
              netMsk=${items[2]}
              lseTme=$((${items[-1]//h/} * 3600))
            fi
          fi
          uci_set $cfn "$curSection" 'MinAddress' "$rngMin"
          uci_set $cfn "$curSection" 'MaxAddress' "$rngMax"
          uci_set $cfn "$curSection" 'SubnetMask' "$netMsk"
          uci_set $cfn "$curSection" 'DHCPLeaseTime' "$lseTme"
        fi
        ((iNum++))
      done
    fi
    uci commit
  }
  ##CONFIG===========================================================
  _set() {
    #-----------------------------------
    __wrtYHdr() {
      echo "$hdrTip"
      echo "network:"
      echo "  version: 2"
      echo "  ethernets:"
    }
    #-----------------------------------
    __wrtYWan() {
      echo "    ${InterfaceName}:"
      echo "      dhcp6: false"
      if [ "X${IPInterfaceAddressingType,,}" != "Xstatic" ]; then
        echo "      dhcp4: true"
        echo "      dhcp4-overrides:"
        echo "        route-metric: ${RouteMetric}"
      else
        if [ ${ENABLE_IP_HOOK-1} -eq 1 ]; then
          ip link set dev $InterfaceName down
          ip addr flush dev $InterfaceName scope global
          ip addr replace dev $InterfaceName $IPv4Address
          ip link set dev $InterfaceName up
        fi
        echo "      dhcp4: false"
        echo "      addresses: [ $IPv4Address ]"
        echo "      nameservers:"
        echo "        addresses: [ ${IPv4DNS}${IPv4BackupDNS:+,$IPv4BackupDNS} ]"
        echo "      routes:"
        echo "      - to: 0.0.0.0/0"
        echo "        via: $IPv4Gateway"
        echo "        on-link: true"
        echo "        metric: $RouteMetric"
      fi
    }
    #-----------------------------------
    __wrtYLan() {
      echo "    LAN:"
      echo "      match:"
      echo "        name: eth[${PortInterface//[^0-9]/}]"
      echo "  bridges:"
      echo "    ${InterfaceName}:"
      echo "      interfaces: [ LAN ]"
      echo "      macaddress: $(cat /sys/class/net/${PortInterface%%,*}/address)"
      echo "      mtu: $MTU"
      echo "      dhcp6: false"
      echo "      dhcp4: false"
      echo "      addresses: [ ${IPv4Address} ]"
      echo "      nameservers:"
      echo "        addresses: [ 223.5.5.5,114.114.114.114 ]"
    }
    #-----------------------------------
    __wrtDnsmasq() {
      local leasetime="12h" dns="223.5.5.5,114.114.114.114"
      [ "X$DHCPLeaseTime" == "X3600" ] && leasetime="1h"
      [ "X$DNSServers" != "X" ] && dns=$DNSServers
      echo "$hdrTip"
      echo "conf-dir=/etc/dnsmasq.d"
      echo "bind-interfaces"
      echo "interface=${InterfaceName}"
      echo "#log-facility=/var/log/dnsmasq.log"
      echo "dhcp-range=${MinAddress},${MaxAddress},$SubnetMask,${leasetime}"
      echo "dhcp-authoritative"
      echo "dhcp-leasefile=/run/dnsmasq.leases"
      echo "dhcp-option=3,${IPv4Address%%/*}"
      echo "dhcp-option=6,${dns}"
      echo "dhcp-no-override"
      echo "dhcp-lease-max=200"
      echo "#log-dhcp"
      echo "#port=0"
      echo "#strict-order"
    }
    #-----------------------------------
    systemctl stop systemd-networkd 2>/dev/null
    local hdrTip="## re-create by HCLINK $(date +'%F %T')"
    #-----------------------------------
    local fctn='/tmp/cur.ctn' fenv='/tmp/cur.env' sid=0 spf=
    local tmpYml=/tmp/ip2set.yml
    __wrtYHdr >$tmpYml

    ##update wans
    local sectype=wan
    while :; do
      uci show "$cfn.@$sectype[$sid]" 2>/dev/null >$fctn
      [ -s $fctn ] || break
      (
        tail -n +2 $fctn | sed "s#$(head -n1 $fctn | sed 's#=.*#.#g')##g" >$fenv
        source $fenv
        __wrtYWan >>$tmpYml
      )
      ((sid++))
    done

    ##update lans
    sectype=lan sid=0
    uci show "$cfn.@$sectype[$sid]" 2>/dev/null >$fctn
    if [ -s $fctn ]; then
      (
        tail -n +2 $fctn | sed "s#$(head -n1 $fctn | sed 's#=.*#.#g')##g" >$fenv
        source $fenv
        if [ "X${DHCPv4Enable-1}" == "X1" ]; then
          __wrtDnsmasq >$dhcpcfile
        fi
        __wrtYLan >>$tmpYml
        if [ ${ENABLE_IP_HOOK-1} -eq 1 ]; then
          ip link set dev $InterfaceName down
          (
            bnme="${InterfaceName}" ifc=
            systemctl stop systemd-networkd
            cd /sys/class/net/ $bnme
            echo lower_* | xargs -n1 | sed 's#lower_##g' | xargs brctl delif $bnme
            echo ${PortInterface//,/ } | xargs -n1 | xargs brctl addif $bnme

            if [ "X$(pgrep hostapd)" != "X" ]; then
              wificfile=$(ps -ef | awk '!/awk/ && /hostapd/' | xargs -n1 | awk '/.cnf$/')
              awk '/^(interface|bridge)=/' $wificfile | sed 's,[" ],,g' >/tmp/tmp.env
              source /tmp/tmp.env
              if [ "X$bridge" == "X$InterfaceName" ]; then
                brctl addif $bnme $interface
              fi
            fi
          )
          ip addr flush dev $InterfaceName scope global
          ip addr add dev $InterfaceName $IPv4Address
          ip link set dev $InterfaceName up
        fi
        if [ ${ENABLE_IP_HOOK-1} -eq 1 ]; then
          systemctl restart dnsmasq
        fi
      )
    fi
    cp $tmpYml $(_getCurYml)
    rm -f $fctn $tmpYml $fenv 2>/dev/null
  }
  #===MAIN====================================================
  if [ "X$(command -v uci 2>/dev/null)" == "X" ] ||
    [ "X$(command -v uci_set 2>/dev/null)" == "X" ]; then
    return 1
  fi
  local tNAME=$(tn=${BASH_SOURCE##*/} && echo ${tn}) tOBJ="{lan|wan}"
  local op=$1 obj=$2
  if [[ "X$op" != "Xstatus" && "X$op" != "Xconfig" ]] ||
    [[ "X$obj" != "Xwan" && "X$obj" != "Xlan" ]]; then
    echo "Usage: $tNAME { status ${tOBJ} | config ${tOBJ} }"
    return 2
  fi
  shift 2
  #-----------------------------------
  [ -e network2 ] && cp network2 /data/hclink/etc/config && uci commit
  [ ${G_BAK_CFG-0} -eq 1 ] && cp $cfp /home/${cfn}.$obj.$op
  #-----------------------------------
  local iNum=1 iface= v4IP= v4GW=
  case $op in
  status) _get $@ ;;
  config) _set $@ ;;
  esac
}

[ "X${0: -4}" = "Xbash" ] || hcl.ip2 $@
