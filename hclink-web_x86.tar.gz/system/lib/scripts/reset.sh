#!/bin/sh

#恢复data区

#恢复fibo配置文档
