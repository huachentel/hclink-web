#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

MAX_LOGSIZE=$(expr 1048 \* 1024)
if [ -z "$1" ]; then
  LOG_FILE=${DATA_ROOT}/log/hclink_agent.log
else
  LOG_FILE=${DATA_ROOT}/log/$1
fi
logrotate() {
  local logfile=$1
  local maxsize=$2

  if [ ! -f "$logfile" ]; then
    touch $logfile
    return 0
  fi

  filesize=$(ls -l $logfile | awk '{ print $5 }')

  if [ $filesize -gt $maxsize ]; then
    rm -rf ${logfile}.0 &>/dev/null
    cp $logfile ${logfile}.0
    rm -rf $logfile
  fi
}

logrotate $LOG_FILE $MAX_LOGSIZE
