#告警记录的查询删除添加等操作
#alarm tmp 是对某告警状态的临时记录，避免重复告警
#alarm log 是新告警产生或消除进行记录
#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh

ALARM_FILE_TMP='alarm_tmp'
ALARM_FILE_LOG='alarm'

#$1 alarm id
alarm_tmp_add() {
  uci_add $ALARM_FILE_TMP 'alarm' $1
}

#$1 alarm id
alarm_tmp_del() {
  uci_remove $ALARM_FILE_TMP $1
}

#$1 alarm id
alarm_tmp_get() {
  uci_get $ALARM_FILE_TMP $1
  return $?
}

# $1 instance num
# $2 code
# $3 告警级别
# $4 mark　告警说明
alarm_log_add() {
  local count

  uci_add $ALARM_FILE_LOG 'alarm_info' $1
  uci_set $ALARM_FILE_LOG "$1" 'instance_num' $1
  uci_set $ALARM_FILE_LOG "$1" 'AlarmCode' $2
  uci_set $ALARM_FILE_LOG "$1" 'PerceivedSeverity' $3
  uci_set $ALARM_FILE_LOG "$1" 'AlarmRaisedTime' "$(date "+%Y-%m-%d %H:%M:%S")"
  uci_set $ALARM_FILE_LOG "$1" 'AlarmDetail' $4

  count=$(uci_get ${ALARM_FILE_LOG} @alarm_statistics[0] 'count')
  let 'count+=1'
  uci_set $ALARM_FILE_LOG '@alarm_statistics[0]' 'count' $count

  uci_commit $ALARM_FILE_LOG
}

# $1 instance num
alarm_log_del() {
  local count

  uci_remove $ALARM_FILE_LOG $1
  if [ "$?" == "0" ]; then
    count=$(uci_get ${ALARM_FILE_LOG} @alarm_statistics[0] 'count')
    let 'count-=1'
    uci_set $ALARM_FILE_LOG '@alarm_statistics[0]' 'count' $count
  fi
  uci_commit $ALARM_FILE_LOG
}

if [ ! -f ${DATA_ROOT}/etc/config/${ALARM_FILE_TMP} ]; then
  touch ${DATA_ROOT}/etc/config/${ALARM_FILE_TMP}
fi

if [ "$1" != "log" ] && [ -z "$2" ]; then
  echo 'alarm num is null!'
  exit 1
fi

case $1 in
'add')
  alarm_tmp_add $2
  uci_commit
  ;;
'del')
  alarm_tmp_del $2
  uci_commit
  ;;
'get')
  alarm_tmp_get $2
  if [ $? != 0 ]; then
    exit 2
  fi
  ;;
'log')
  case $2 in
  'add')
    alarm_log_add $3 $4 $5 $6
    ;;
  'del')
    alarm_log_del $3
    ;;
  'clean')
    echo "" >${DATA_ROOT}/etc/config/${ALARM_FILE_LOG}
    rm -rf ${UCI_CONFIG_TMP_DIR}/${ALARM_FILE_LOG}
    uci_add $ALARM_FILE_LOG 'alarm_statistics'
    uci_set $ALARM_FILE_LOG "@alarm_statistics[0]" 'count' '0'
    uci_commit $ALARM_FILE_LOG
    sync
    ;;
  *)
    echo "add | del | clean"
    ;;
  esac
  ;;
*)
  echo "add|del|get|log"
  ;;
esac
