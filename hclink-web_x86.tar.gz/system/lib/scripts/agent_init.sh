#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh
SN_FILE='/data/hclink/recovery/sn'
IMEI_FILE='/data/hclink/recovery/IMEI'

ALARM_FILE='alarm'
ALARM_FILE_TMP='alarm_tmp'
AT_CLIENT="/usr/local/bin/atcmdtool"
if [ "$AGENT_SYSTEM" == "ubuntu" ]; then
  AT_CLIENT="/usr/local/bin/atcmdtool"
else
  AT_CLIENT="${AGENT_FS_ROOT}/system/bin/hclink_at_client"
fi

#======================================================

Module_init(){
  local arch=`uname -m`
  if [ "$arch" == "x86_64" ]; then
    modprobe usbserial
    echo "2cb7 0104" >/sys/bus/usb-serial/drivers/generic/new_id
    echo "2cb7 0105" >/sys/bus/usb-serial/drivers/generic/new_id
    echo "05c6 9008" >/sys/bus/usb-serial/drivers/generic/new_id
  fi
}
#======================================================
version_init() {
  local software="$(uci_get system @devinfo[0] SoftwareVersion)"
  local hardware="$(uci_get system @devinfo[0] HardwareVersion)"
  echo [version] >${DATA_ROOT}/var/version
  echo "software=$software" >>${DATA_ROOT}/var/version
  echo "hardware=$hardware" >>${DATA_ROOT}/var/version
}

#======================================================
IMEI_get() {
  local val=
  for x in 1 2 3; do
    val=$($AT_CLIENT 'at+cgsn' 2>/dev/null | awk '/[0-9]/{print $1}')
    [ "X$val" == "X" ] && sleep 2 || break
  done
  if [ "X$val" == "X" ]; then
    echo "IMEI GET ERROR!!!" >${DATA_ROOT}/log/error.log
    exit 1
  else
    IMEI="$val"
    return 0
  fi
}

#======================================================
#修改，IMEI不从模组读取，而是仅从文件读取
sn_init() {
  local IMEI_SUB
  local SN
  typeset -u SN

  if [ ! -f $IMEI_FILE ]; then
    #IMEI_get
    IMEI=000000000000000
    echo $IMEI >$IMEI_FILE
  else
    IMEI="$(cat $IMEI_FILE)"
  fi

  # if [ ! -f $SN_FILE ]; then
  #     #IMEI_get
  #     IMEI_SUB=${IMEI:0:14}
  #     SN=$(printf "00001%x" $IMEI_SUB)
  #     echo $SN > $SN_FILE
  # else
  #     SN="$(cat $SN_FILE)"
  # fi
  IMEI_SUB=${IMEI:0:14}
  SN=$(printf "00001%x" $IMEI_SUB)

  uci_set 'system' '@devinfo[0]' 'SerialNumber' $SN
  uci_set 'system' '@devinfo[0]' 'IMEI' $IMEI
  uci_commit 'system'
}

#======================================================
alarm_init() {
  echo 'alarm init'
  rm -rf ${DATA_ROOT}/etc/config/${ALARM_FILE_TMP}
  if [ ! -f ${DATA_ROOT}/etc/config/${ALARM_FILE} ]; then
    touch ${DATA_ROOT}/etc/config/${ALARM_FILE}
  fi
  uci_get $ALARM_FILE "@alarm_statistics[0]"
  if [ "$?" != "0" ]; then
    uci_add $ALARM_FILE 'alarm_statistics'
    uci_set $ALARM_FILE "@alarm_statistics[0]" 'count' '0'
    uci_commit $ALARM_FILE
  fi
}

#======================================================
gps_init() {
  $AT_CLIENT 'ate0'
  $AT_CLIENT 'ate0'
  $AT_CLIENT 'at+gtgpspower=1'
  $AT_CLIENT 'at+gtgpspower=1'
}

Module_init
version_init
sn_init
alarm_init
gps_init
exit 0
