#!/usr/bin/env bash
#=====================================================================
# COPYSTR: Copyright (c) 2020 By HuachenLink, All Rights Reserved.
# FLENAME: wlan.sh
# CONTACT: liudongguo@huachen.link
# CREATED: 2020-11-14 06:54:49
# LTSVERN: 0.1
# LTSUPDT: 2020-11-17 00:04:02
#=====================================================================
#adopter-for-new-data-to-update-into-uci-settings
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
source ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh &>/dev/null

CONFIG_FILE='wlan'

hcl.wlan() {
  local cfn=$CONFIG_FILE
  local cfp=${DATA_ROOT:-/data/hclink}/etc/config/$cfn
  [ -e $cfp ] || touch $cfp

  #==============================================
  _cok() { echo -e "[\e[32;1mOK\e[0m] $*"; }
  #==============================================
  _cwrn() { echo -e "[\e[31;43;5;1mWARN\e[0m] $*"; }
  #==============================================
  _cerr() { echo -e "[\e[31;5;1mERROR\e[0m] $*"; }
  #==============================================
  _hlpClean() {
    while :; do
      uci_remove $cfn "@wlan[-1]" &>/dev/null
      [ $? -ne 0 ] && break
    done
  }

  ##STATUS===========================================================
  _get() {
    _hlpClean
    local obj=$cfn syi=
    local curSection="@${obj}[-1]"
    uci_add $cfn $obj
    uci_set $cfn "$curSection" "instance_num" "1"
    uci_set $cfn "$curSection" "BeaconType" "WPA2"
    uci_set $cfn "$curSection" "WPAAuthenticationMode" "WPA2/WPS-PSK"
    uci_set $cfn "$curSection" "Standard" "ac"
    uci_set $cfn "$curSection" "BandWidth" "20MHz"
    uci_set $cfn "$curSection" "AutoChannelEnable" "1"

    local atype="2.4G"
    [ "X$(awk -F '=' '/^hw_mode=/{print $2}' $apcfgfile)" != "Xg" ] && atype="5G"
    uci_set $cfn "$curSection" "X_CU_Band" "${atype}"
    
    local achnl=$(awk -F '=' '/^channel=/{print $2}' $apcfgfile) 
    uci_set $cfn "$curSection" "Channel" "${achnl}"

    local apass=$(awk -F '=' '/^wpa_passphrase=/{print $2}' $apcfgfile)
    uci_set $cfn "$curSection" "PreSharedKey" "${apass}"

    local assid=$(awk -F '=' '/^ssid=/{print $2}' $apcfgfile)
    [ "X$assid" == "X" ] && assid='huachenlink'
    uci_set $cfn "$curSection" "SSID" "${assid}"

    local arpid=$(pgrep hostapd 2>/dev/null)
    [ "X$arpid" != "X" ] && arpid=1 || arpid=0
    uci_set $cfn "$curSection" "Enable" "${arpid}"

    uci commit
  }
  ##CONFIG===========================================================
  _set() {
    __uptHostapdCfg() {
      local vap='OPEN' vat=1 vas= cmt=
      local susg="[-p AP_PASS={$vap}] [-s AP_SSID={$vas}] [-t AP_TYPE={$vat}]"
      while :; do
        case $1 in
        -h | --help | help) echo "Usage: $utlName hostapd $susg" && return ;;
        -t | --ap-type) shift && [[ "X$1" == "X2" || "X$1" == "X5.8G" ]] && vat=2 ;;
        -s | --ap-ssid) shift && vas=$1 ;;
        -p | --ap-pass) shift && vap=$1 ;;
        "")
          : '#DO-CHECK-BEGIN'
          #check ssid
          case $vas in
          "" | [dD] | DFLT* | default) vas='huachenlink' ;;
          esac
          local syi="/sys/class/net/${wlsnic}"
          if [[ "X$vas" == "Xhuachenlink" && "X" != "X$(command ls -d1 $syi 2>/dev/null)" ]]; then
            vas="$vas-"$(cat $syi/address 2>/dev/null | awk -F':' '{print toupper($(NF-1))""toupper($NF)}')
          fi
          #check password

          case $vap in
          [oO] | open | OPEN)
            vap= && cmt='#'
            : _cwrn 'you will setup an open wifi (without acess-password).'
            ;;
          [dD] | default | DFLT*)
            vap='1234567890'
            : _cwrn "you will use < $vap > as wifi acess-password."
            ;;
          esac
          rm -f $cdir/hostap-5g.cnf 2>/dev/null
          : '#DO-CHECK-OVER'
          break
          ;;
        esac
        shift
      done
      {
        echo $hdrtip
        echo 'ssid='$vas
        echo 'interface='$wlsnic
        echo ${cmt}'wpa_passphrase='${vap:-1234567890}
        echo ${cmt}'wpa=2'
        echo ${cmt}'rsn_pairwise=CCMP'
        echo ${cmt}'wpa_key_mgmt=WPA-PSK'
        [ "X$g_osflag" == "X" ] && echo 'bridge=br-lan'
        echo 'country_code=CN'
        echo 'ieee80211n=1'
        echo 'require_ht=1'
        if [ "X$vat" == "X1" ]; then
          echo 'hw_mode=g'
          echo 'channel=11'
          echo 'ht_capab=[SHORT-GI-40][HT20][RX-STBC1][DSSS_CCK-40]'
        else
          echo 'hw_mode=a'
          echo 'channel=157'
          echo 'ieee80211ac=1'
          echo 'ht_capab=[SHORT-GI-40][HT40+][RXLDPC][TX-STBC-2BY1][RX-STBC-1]'
          echo 'ieee80211d=1'
          echo 'ieee80211h=1'
          echo 'require_vht=1'
          echo 'vht_oper_chwidth=1'
          echo 'vht_oper_centr_freq_seg0_idx=155'
          echo 'vht_capab=[MAX-MPDU-11454][SHORT-GI-80][RXLDPC][TX-STBC-2BY1][RX-STBC-1]'
        fi
        echo
        echo '#beacon_int=100'
        echo '#obss_interval=0'
        echo 'dtim_period=2'
        echo 'max_num_sta=255'
        echo 'rts_threshold=2347'
        echo '#fragm_threshold=2346'
        echo 'macaddr_acl=0'
        echo 'auth_algs=3'
        echo 'ignore_broadcast_ssid=0'
        echo 'ap_isolate=0'
        echo 'wmm_enabled=1'
        echo 'eapol_key_index_workaround=0'
        echo 'eap_server=0'
        echo 'own_ip_addr=127.0.0.1'
        echo 'logger_syslog=-1'
        echo 'logger_syslog_level=2'
        echo 'logger_stdout=-1'
        echo 'logger_stdout_level=2'
        echo 'ctrl_interface=/var/run/hostapd'
        echo 'ctrl_interface_group=0'
        echo $hdrtip
        echo
      } >$apcfgfile
      local tip="SSID: $vas${vap:+, PASSWORD: $vap}"
      _cok "update < $apcfgfile > done, [ $tip ]."
    }
    __uptHostapdSvc() {
      echo $hdrtip
      echo && echo '[Unit]'
      echo "Description=HCLINK-WIFI-Daemon on wireless iface $wlsnic"
      echo "Requires=sys-subsystem-net-devices-$wlsnic.device"
      echo "After=sys-subsystem-net-devices-$wlsnic.device"
      echo 'Before=network.target'
      echo 'Wants=network.target'
      echo && echo '[Service]'
      echo 'ExecStart=/usr/sbin/hostapd /etc/hostapd/hostap.cnf'
      echo 'ExecReload=/bin/kill -HUP $MAINPID'
      echo 'TimeoutStartSec=30s'
      echo 'Restart=on-failure'
      echo 'RestartSec=30s'
      echo && echo '[Install]'
      echo 'WantedBy=multi-user.target'
      echo $hdrtip && echo
    }
    #-----------------------------------
    #目前只有一个实例所以就单次读取
    #-----------------------------------
    local fctn='/tmp/cur.ctn' fenv='/tmp/cur.env' sid=0
    uci show $cfn.@$cfn[0] 2>/dev/null >$fctn
    if [ -s $fctn ]; then
      (
        local atype=1
        tail -n +2 $fctn | sed "s#$(head -n1 $fctn | sed 's#=.*#.#g')##g" >$fenv
        source $fenv
        [ "X$X_CU_Band" == "X5G" ] && atype=2
        __uptHostapdCfg -t $atype ${SSID:+ -s $SSID} ${PreSharedKey:+ -p $PreSharedKey}
        if [ "X$Enable" == "X1" ]; then
          __uptHostapdSvc >/lib/systemd/system/hostapd${wlsidx}.service
          systemctl unmask hostapd
          systemctl enable --now hostapd
        fi
      )
    fi
    # rm -f $fctn $fenv 2>/dev/null
  }
  #===MAIN====================================================
  if [ "X$(command -v uci 2>/dev/null)" == "X" ] ||
    [ "X$(command -v uci_set 2>/dev/null)" == "X" ]; then
    return 1
  fi
  local op=$1
  if [[ "X$op" != "Xstatus" && "X$op" != "Xconfig" ]]; then
    echo "Usage: $tNAME {status|config}"
    return 2
  fi
  shift
  local hdrtip="## re-generateby HCLINK @$(date +'%F %T')@"
  local tNAME=$(tn=${BASH_SOURCE##*/} && echo ${tn})
  local wlsidx=${CFG_WLS_INDEX} wlsnic=${CFG_WLS_INDEX}
  [ "X$wlsnic" == "X" ] && wlsnic=$(cd /sys/class/net && echo wl*)
  [ "X$wlsnic" == "X" ] && wlsnic='wlp1s0'
  local cdir=/etc/hostapd
  local apcfgfile=$cdir/hostap${wlsidx}.cnf
  [ -d $cdir ] || mkdir -p $cdir
  #-----------------------------------
  [ -e $cfn ] && cp $cfn /data/hclink/etc/config && uci commit
  [ ${G_BAK_CFG-0} -eq 1 ] && cp $cfp /home/${cfn}.$op
  #-----------------------------------
  local iNum=1 iface= v4IP= v4GW=
  case $op in
  status) _get $@ ;;
  config) _set $@ ;;
  esac
}

[ "X${0: -4}" = "Xbash" ] || hcl.wlan $@
