#!/bin/bash
[ -z "$AGENT_FS_ROOT" ] && echo "ERR! missing environment variable :'AGENT_FS_ROOT'!" && exit
. ${AGENT_FS_ROOT}/system/lib/scripts/cpelib_core.sh
